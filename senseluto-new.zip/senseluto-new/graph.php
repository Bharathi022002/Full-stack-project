<?php
include('conn.php');
 ?>

<!DOCTYPE html>
<html>
 
<head>
  <meta charset="utf-8">
  <title>ZingSoft Demo</title>
 
  <script nonce="undefined" src="https://cdn.zingchart.com/zingchart.min.js"></script>
  <style>
    html,
    body,
    #myChart {
      height: 100%;
      width: 100%;
    }
  </style>
</head>
 
<body>
  <?php
    $query = "SELECT `temperature`,`ph`,`moisture` FROM `sens_data` order by `id` DESC limit 1  ";
    $result = mysqli_query($con, $query);

    while($row = mysqli_fetch_array($result))
    {
       $chart_data1 = $row["temperature"];
       $chart_data2 = $row["moisture"];
       $chart_data3 = $row["ph"];
    }

    ?>
  <div id='myChart'></div>
  <script>
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];
    var myConfig9 = {
      "type": "gauge",
      "scale": {
        "size-factor": 0.7
      },
      "scale-2": {
        "size-factor": 1
      },
      "scale-3": {
        "size-factor": 1.2
      },
      "scale-r": {
                                                "aperture": 200,
                                                "values": "0:100:20",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 40",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 40 && %v <= 70",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 70 && %v <= 80",
                                                      "background-color": "red"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      "scale-r-2": {
                                                "aperture": 200,
                                                "values": "0:100:10",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 30",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 30 && %v <= 70",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 70 && %v <= 100",
                                                      "background-color": "blue"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      "scale-r-3": {
                                                "aperture": 200,
                                                "values": "0:8:1",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 4",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 4 && %v <= 7",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 7 && %v <= 8",
                                                      "background-color": "red"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      
      
      "series": [{
          "values": [<?php echo $chart_data1; ?>],
          "csize": "5%",
          "size": "90%"
        },
        {
          "values": [<?php echo $chart_data2; ?>],
          "scales": "scale-2,scale-r-2", //Specify which scale your data should plot to.
          "csize": "5%",
          "size": "90%"
        },
        {
          "values": [<?php echo $chart_data3; ?>],
          "scales": "scale-3,scale-r-3", //Specify which scale your data should plot to.
          "csize": "5%",
          "size": "90%"
        }
      ]
    };
 
    zingchart.render({
      id: 'myChart',
      data: myConfig9,
      height: "250",
      width: "250"
    });
  </script>
</body>
 
</html>