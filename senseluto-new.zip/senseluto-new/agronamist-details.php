<?php
include("conn.php");
$uid=$_SESSION['userid'];
$image=$_SESSION['image'];
$name=$_SESSION['name'];
$email=$_SESSION['email'];
$gid=$_SESSION['gid'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:title" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:image" content="https://zenix.dexignzone.com/xhtml/social-image.png" />
	<meta name="format-detection" content="telephone=no">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
	
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

       <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <?php include "header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************--> 
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-12">
						<div class="card">
							<div class="card-body d-flex justify-content-between align-items-center">
								<div>
									<h4>Agronamist details</h4>
								</div>
							</div>
						</div>
					</div>
					<?php 
                    $part=mysqli_query($con,"SELECT * FROM `agronist`")or die(mysqli_error($con));
                    while($p=mysqli_fetch_array($part))
                    {
                                              	
		             ?>
					<div class="col-xl-3 col-xxl-4 col-sm-6">
						<div class="card user-card">
							<div class="card-body pb-0">
								<div class="d-flex mb-3 align-items-center">
									<div class="dz-media mr-3">
										<img src="<?php echo $p['profile'] ?>" alt="">
									</div>
									<div>
										<h5 class="title"><a><?php echo $p['name'] ?></a></h5>
										<span class="text-primary">Senior Developer</span>
									</div>
								</div>
								<p class="fs-12"><?php echo $p['specialist'] ?></p>
								<ul class="list-group list-group-flush">
									<li class="list-group-item">
										<span class="mb-0 title">Email</span> :
										<span class="text-black ml-2"><?php echo $p['email'] ?></span>
									</li>
									<li class="list-group-item">
										<span class="mb-0 title">Phone</span> :
										<span class="text-black ml-2"><?php echo $p['phone'] ?></span>
									</li>
									<li class="list-group-item">
										<span class="mb-0 title">Location</span> :
										<span class="text-black desc-text ml-2"><?php echo $p['location'] ?></span>
									</li>
								</ul>
							</div>
							<div class="card-footer">
								<a href="view-agronamist.php?id=<?php echo $p['id']?>" class="btn btn-success btn-xs">View profile</a>
							</div>
						</div>
					</div>
					<?php
					}
					?>
				</div>
				<nav>
					<ul class="pagination pagination-gutter pagination-primary no-bg">
						<li class="page-item page-indicator">
							<a class="page-link" href="javascript:void(0)">
								<i class="la la-angle-left"></i></a>
						</li>
						<li class="page-item active"><a class="page-link" href="javascript:void(0)">1</a>
						</li>
						<li class="page-item "><a class="page-link" href="javascript:void(0)">2</a></li>
						<li class="page-item"><a class="page-link" href="javascript:void(0)">3</a></li>
						<li class="page-item"><a class="page-link" href="javascript:void(0)">4</a></li>
						<li class="page-item page-indicator">
							<a class="page-link" href="javascript:void(0)">
								<i class="la la-angle-right"></i></a>
						</li>
					</ul>
				</nav>
			</div>
		</div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->
		
		
		
		
		
		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="vendor/global/global.min.js"></script>
	<script src="vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="vendor/chart.js/Chart.bundle.min.js"></script>
	
	<!-- Datatable -->
	<script src="vendor/datatables/js/jquery.dataTables.min.js"></script>
	<script src="js/plugins-init/datatables.init.js"></script>
	
    <script src="js/custom.min.js"></script>
	<script src="js/deznav-init.js"></script>

</body>
</html>