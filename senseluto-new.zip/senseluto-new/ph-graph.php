<?php
include("conn.php");
?>

<!DOCTYPE html>
<html>
 
<head>
  <meta charset="utf-8">
  <title>ZingSoft Demo</title>
 
  <script nonce="undefined" src="https://cdn.zingchart.com/zingchart.min.js"></script>
  <style>
    html,
    body,
    #myChart {
      height: 100%;
      width: 100%;
    }
  </style>
</head>
 
<body>
  <?php
  $query = "SELECT `ph` FROM `sens_data` where `id`='1'";
  $result = mysqli_query($con, $query);

while($row = mysqli_fetch_array($result))
{
 $chart_data = $row["ph"];
}

?>  
   
  <div id='myChart'></div>
  <script>
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];
    
    var myConfig6 = {
      "type": "gauge",
      "scale-r": {
        "aperture": 200,
        "values": "0:100:20",
        "center": {
          "size": 5,
          "background-color": "#66CCFF #FFCCFF",
          "border-color": "none"
        },
        "ring": { //Ring with Rules
          "size": 10,
          "rules": [{

              "rule": "%v >= 0 && %v <= 40",
              "background-color": "red"
            },
            {
              "rule": "%v >= 40 && %v <= 70",
              "background-color": "green"
            },
            {
              "rule": "%v >= 70 && %v <= 80",
              "background-color": "yellow"
            },
            
          ]
        }
      },
      "plot": {
        "csize": "5%",
        "size": "100%",
        "background-color": "#000000"
      },
      "series": [{
        "values": [<?php echo $chart_data; ?>]
      }]
    };
 
    zingchart.render({
      id: 'myChart',
      data: myConfig6,
      values:'series',
      height: "100%",
      width: "100%"
    });
  </script>
</body>
 
</html>