<?php 
                                        $command = escapeshellcmd('file/python test.py');
                                        $output=shell_exec($command);
                                        echo $output;
                                        ?>