<?php
include('conn.php');
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

       
       <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end 
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
        
       

        <!--**********************************
            Content body start
        ***********************************-->
<div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="javascript:void(0)">Suggestion to pour water</a></li>
					</ol>
                </div>
                <div class="row">
                	<?php 
                    $part=mysqli_query($con,"SELECT `moisture` FROM `sens_data` order by `id` DESC limit 1 ")or die(mysqli_error($con));
                     while($p=mysqli_fetch_array($part))
                    {
                    if($p["moisture"] < 50)
                    {
                    ?>
                    
                    <div class="col-xl-6">
                        <div class="card text-white bg-success">
                        	 <div class="card-header">
                        	<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="https://img.icons8.com/ios-filled/50/000000/watering-can.png"/>
											</span>
                            
                                <h5 class="card-title text-white">suggestion to water</h5>
                            </div>
                            <div class="card-body mb-0">
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p><a href="javascript:void()" class="btn btn-success light btn-card">YES</a>
                            </div>
                        </div>
                    </div>
                
                    <?php
                    }
                    else
                    {
                    ?>	
                    
                    <div class="col-xl-6">
                        <div class="card text-white bg-danger">
                            <div class="card-header">
                        	<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="https://img.icons8.com/ios-filled/50/000000/watering-can.png"/>
											</span>
                                <h5 class="card-title text-white">suggestion not to water</h5>
                            </div>
                            <div class="card-body mb-0">
                                <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p><a href="javascript:void()" class="light btn btn-danger btn-card">NO</a>
                            </div>
                            <div class="card-footer bg-transparent border-0 text-white">
                            </div>
                        </div>
                    </div>
                
                    <?php
                }
            }
                ?>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>	
	
</body>

</html>