<div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by Nandha Infotech <a href="https://nandhainfotech.com/" target="_blank">Nandha Infotech</a> 2021</p>
            </div>
        </div>