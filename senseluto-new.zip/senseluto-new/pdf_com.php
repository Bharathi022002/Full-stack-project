<?php

function generateRow(){
	require('conn.php');
		$contents = '';
	 	//$id=$_GET['id'];
		$res=$con->query("select * from jobacard");
	
		
			while($row=$res->fetch_assoc())
			{
			//$id = $row['Id'];
		
                      
	      	
			$contents .= '
			<tr>
				<td>'.$row['jbc_id'].'</td>
				<td>'.$row['name'].'</td>
				<td>'.$row['cnumber'].'</td>
			
				<td>'.$row['MaterialName'].'</td>
				<td>'.$row['Quantity'].'</td>
				<td>'.$row['customersideprob'].'</td>
				<td>'.$row['servicetype'].'</td>
				<td>'.$row['status'].'</td>
			
			
			</tr>
			';
		}

		
		return $contents;
	}
		

	
	require_once('TCPDF-main/tcpdf.php');  
    $pdf = new TCPDF('P', PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);  
    $pdf->SetCreator(PDF_CREATOR);  
      
    $pdf->SetHeaderData('', '', PDF_HEADER_TITLE, PDF_HEADER_STRING);  
    $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));  
    $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));  
    $pdf->SetDefaultMonospacedFont('helvetica');  
    $pdf->SetFooterMargin(PDF_MARGIN_FOOTER);  
    $pdf->SetMargins(PDF_MARGIN_LEFT, '10', PDF_MARGIN_RIGHT);  
    $pdf->setPrintHeader(false);  
    $pdf->setPrintFooter(false);  
    $pdf->SetAutoPageBreak(TRUE, 10);  
    $pdf->SetFont('helvetica', '', 11);  
    $pdf->AddPage();  
    $content = '';  
    $content .= '
      	
		<h2 align="center">JOBCARD DETAILS</h2>
      		
      	<table border="1" cellspacing="1" cellpadding="3">  
           <tr>  
         	<th>Jobcard id</th>
         	<th>Name</th>
         	<th>cnumber</th>
         	<th>MaterialName</th>
			<th>Quantity</th>
			<th>Problem Statement</th>
			<th>servicetype</th>
			<th>status</th>
           </tr>  
      ';  
   $content .= generateRow(); 
    $content .= '</table>';  
    $pdf->writeHTML($content);  
    $pdf->Output('Report.pdf', 'I');

?>