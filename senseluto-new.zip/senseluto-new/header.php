<div class="nav-header">
            <a href="dashboard.php" class="brand-logo">
                <img class="logo-abbr" src="./image/logo.png" alt="">
                <img class="logo-compact" src="./image/logo-text.png" alt="">
                <img class="brand-title" src="./image/logo-text.png" alt="">
            </a>

            <div class="nav-control">
                <div class="hamburger">
                    <span class="line"></span><span class="line"></span><span class="line"></span>
                </div>
            </div>
        </div>