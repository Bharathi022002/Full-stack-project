<?php 
include("conn.php");
$uid=$_SESSION['userid'];
$image=$_SESSION['image'];
$name=$_SESSION['name'];
$email=$_SESSION['email'];
$gid=$_SESSION['gid'];

$temp_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";
$data_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:title" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:image" content="https://zenix.dexignzone.com/xhtml/social-image.png" />
	<meta name="format-detection" content="telephone=no">
    <title><?=$title?></title>
    <script nonce="undefined" src="https://cdn.zingchart.com/zingchart.min.js"></script>
  <style>
    html,
    body,
    #myChart {
      height: 200;
      width: 250;
    }
  </style>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <?php include "header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
			
			<div class="container-fluid">
				<div class="form-head mb-sm-5 mb-3 d-flex flex-wrap align-items-center">
					<h2 class="font-w600 title mb-2 mr-auto ">Dashboard</h2>
				</div>
				<div class="row">
					<div class="col-xl-3 col-sm-6 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
								<svg class="mb-3 currency-icon" width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="40" cy="40" r="40" fill="white"/>
									<path d="M40.725 0.00669178C18.6241 -0.393325 0.406678 17.1907 0.00666126 39.275C-0.393355 61.3592 17.1907 79.5933 39.2749 79.9933C61.3592 80.3933 79.5933 62.8093 79.9933 40.7084C80.3933 18.6241 62.8092 0.390041 40.725 0.00669178ZM39.4083 72.493C21.4909 72.1597 7.17362 57.3257 7.50697 39.4083C7.82365 21.4909 22.6576 7.17365 40.575 7.49033C58.5091 7.82368 72.8096 22.6576 72.493 40.575C72.1763 58.4924 57.3257 72.8097 39.4083 72.493Z" fill="#00ADA3"/>
									<path d="M40.5283 10.8305C24.4443 10.5471 11.1271 23.3976 10.8438 39.4816C10.5438 55.549 23.3943 68.8662 39.4783 69.1662C55.5623 69.4495 68.8795 56.599 69.1628 40.5317C69.4462 24.4477 56.6123 11.1305 40.5283 10.8305ZM40.0033 19.1441L49.272 35.6798L40.8133 30.973C40.3083 30.693 39.6966 30.693 39.1916 30.973L30.7329 35.6798L40.0033 19.1441ZM40.0033 60.8509L30.7329 44.3152L39.1916 49.022C39.4433 49.162 39.7233 49.232 40.0016 49.232C40.28 49.232 40.56 49.162 40.8117 49.022L49.2703 44.3152L40.0033 60.8509ZM40.0033 45.6569L29.8296 39.9967L40.0033 34.3364L50.1754 39.9967L40.0033 45.6569Z" fill="#00ADA3"/>
								</svg>
								<?php 
												
                                $reg=mysqli_query($con,"select AVG(`ph`) as aph from ( select `ph` from sens_data WHERE gadget_id='$gid' ORDER BY `sens_data`.`id` DESC limit 3 ) sens_data")or die(mysqli_error($con));
                                while($p=mysqli_fetch_array($reg))
                                {
						         ?>
								<h2 class="text-black mb-2 font-w600"><?php echo number_format(((float)$p['aph']), 2, '.', '');  ?></h2>
								<?php
											}
											?>
								<p class="mb-0 fs-13">
									
									<span class="text-success mr-1">PH</span>
								</p>	
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
								<svg class="mb-3 currency-icon" width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="40" cy="40" r="40" fill="white"/>
									<path d="M40 0C17.9083 0 0 17.9083 0 40C0 62.0917 17.9083 80 40 80C62.0917 80 80 62.0917 80 40C80 17.9083 62.0917 0 40 0ZM40 72.5C22.0783 72.5 7.5 57.92 7.5 40C7.5 22.08 22.0783 7.5 40 7.5C57.9217 7.5 72.5 22.0783 72.5 40C72.5 57.9217 57.92 72.5 40 72.5Z" fill="#FFAB2D"/>
									<path d="M42.065 41.2983H36.8133V49.1H42.065C43.125 49.1 44.1083 48.67 44.7983 47.9483C45.52 47.2566 45.95 46.275 45.95 45.1833C45.9517 43.0483 44.2 41.2983 42.065 41.2983Z" fill="#FFAB2D"/>
									<path d="M40 10.8333C23.9167 10.8333 10.8333 23.9166 10.8333 40C10.8333 56.0833 23.9167 69.1666 40 69.1666C56.0833 69.1666 69.1667 56.0816 69.1667 40C69.1667 23.9183 56.0817 10.8333 40 10.8333ZM45.935 53.5066H42.495V58.9133H38.8867V53.5066H36.905V58.9133H33.28V53.5066H26.9067V50.1133H30.4233V29.7799H26.9067V26.3866H33.28V21.0883H36.905V26.3866H38.8867V21.0883H42.495V26.3866H45.6283C47.3783 26.3866 48.9917 27.1083 50.1433 28.26C51.295 29.4116 52.0167 31.025 52.0167 32.775C52.0167 36.2 49.3133 38.995 45.935 39.1483C49.8967 39.1483 53.0917 42.3733 53.0917 46.335C53.0917 50.2816 49.8983 53.5066 45.935 53.5066Z" fill="#FFAB2D"/>
									<path d="M44.385 36.5066C45.015 35.8766 45.3983 35.0316 45.3983 34.08C45.3983 32.1916 43.8633 30.655 41.9733 30.655H36.8133V37.52H41.9733C42.91 37.52 43.77 37.12 44.385 36.5066Z" fill="#FFAB2D"/>
									
								</svg>
								<?php 
												
                                $reg=mysqli_query($con,"select AVG(`temperature`) as temp from ( select `temperature` from sens_data WHERE gadget_id='$gid' ORDER BY `sens_data`.`id` DESC limit 3 ) sens_data")or die(mysqli_error($con));
                                while($p=mysqli_fetch_array($reg))
                                {
							      ?>
								<h2 class="text-black mb-2 font-w600"><?php echo number_format((float)$p['temp'], 2, '.', '');  ?></h2>
								<?php
											}
											?>
								<p class="mb-0 fs-14">
									<span class="text-info mr-1">Temperature</span>
								</p>	
							</div>
						</div>
					</div>
					
					<div class="col-xl-3 col-sm-6 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
								<svg class="mb-3 currency-icon" width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="40" cy="40" r="40" fill="white"/>
									<path d="M40.725 0.00669178C18.6241 -0.393325 0.406678 17.1907 0.00666126 39.275C-0.393355 61.3592 17.1907 79.5933 39.2749 79.9933C61.3592 80.3933 79.5933 62.8093 79.9933 40.7084C80.3933 18.6241 62.8092 0.390041 40.725 0.00669178ZM39.4083 72.493C21.4909 72.1597 7.17362 57.3257 7.50697 39.4083C7.82365 21.4909 22.6576 7.17365 40.575 7.49033C58.5091 7.82368 72.8096 22.6576 72.493 40.575C72.1763 58.4924 57.3257 72.8097 39.4083 72.493Z" fill="#374C98"/>
									<path d="M40.5283 10.8305C24.4443 10.5471 11.1271 23.3976 10.8438 39.4816C10.5438 55.549 23.3943 68.8662 39.4783 69.1662C55.5623 69.4495 68.8795 56.599 69.1628 40.5317C69.4462 24.4477 56.6123 11.1305 40.5283 10.8305ZM52.5455 56.9324H26.0111L29.2612 38.9483L25.4944 39.7317V36.6649L29.8279 35.7482L32.6447 20.2809H43.2284L40.8283 33.4481L44.5285 32.6647V35.7315L40.2616 36.6149L37.7949 50.2154H54.5122L52.5455 56.9324Z" fill="#374C98"/>
								</svg>
								<?php 
												
                                $reg=mysqli_query($con,"select AVG(`moisture`) as moist  from ( select `moisture` from sens_data WHERE gadget_id='$gid' ORDER BY `sens_data`.`id` DESC limit 3 ) sens_data ")or die(mysqli_error($con));
                                while($p=mysqli_fetch_array($reg))
                                {
							      ?>
								<h2 class="text-black mb-2 font-w600"><?php echo number_format((float)$p['moist'], 2, '.', '');  ?></h2>
								<?php
											}
											?>
								<p class="mb-0 fs-14">
									<span class="text-danger mr-1">Moisture</span>
								</p>	
							</div>
						</div>
					</div>
					<div class="col-xl-3 col-sm-6 m-t35">
						<div class="card card-coin">
							<div class="card-body text-center">
								<svg class="mb-3 currency-icon" width="80" height="80" viewBox="0 0 80 80" fill="none" xmlns="http://www.w3.org/2000/svg">
									<circle cx="40" cy="40" r="40" fill="white"/>
									<path d="M40.725 0.00669178C18.6241 -0.393325 0.406708 17.1907 0.00669178 39.275C-0.393325 61.3592 17.1907 79.5933 39.275 79.9933C61.3592 80.3933 79.5933 62.8093 79.9933 40.7084C80.3933 18.6241 62.8093 0.390041 40.725 0.00669178ZM39.4083 72.493C21.4909 72.1597 7.17365 57.3257 7.507 39.4083C7.82368 21.4909 22.6576 7.17365 40.575 7.49033C58.5091 7.82368 72.8097 22.6576 72.493 40.575C72.1763 58.4924 57.3257 72.8097 39.4083 72.493Z" fill="#FF782C"/>
									<path d="M40.525 10.8238C24.441 10.5405 11.1238 23.391 10.8405 39.475C10.7455 44.5352 11.9605 49.3204 14.1639 53.5139H23.3326V24.8027C23.3326 23.0476 25.7177 22.4893 26.4928 24.0643L40 51.4171L53.5072 24.066C54.2822 22.4893 56.6674 23.0476 56.6674 24.8027V53.5139H65.8077C67.8578 49.6171 69.0779 45.2169 69.1595 40.525C69.4429 24.441 56.609 11.1238 40.525 10.8238Z" fill="#FF782C"/>
									<path d="M53.3339 55.1806V31.943L41.4934 55.919C40.9334 57.0574 39.065 57.0574 38.5049 55.919L26.6661 31.943V55.1806C26.6661 56.1007 25.9211 56.8474 24.9994 56.8474H16.2474C21.4326 64.1327 29.8629 68.9795 39.475 69.1595C49.4704 69.3362 58.3908 64.436 63.786 56.8474H55.0006C54.0789 56.8474 53.3339 56.1007 53.3339 55.1806Z" fill="#FF782C"/>
									
								</svg>
								<h2 class="text-black mb-2 font-w600">18.0</h2>
								<p class="mb-0 fs-14">
									
									<span class="text-warning mr-1">Humidity</span>
								</p>	
							</div>
						</div>
					</div>
				</div>
				<div class="row">
					<div class="col-xl-9 col-xxl-12">
						<div class="card">
							<div class="card-header border-0 flex-wrap pb-0">
								<div class="mb-3">
									<h4 class="fs-20 text-black">Senseluto Overview</h4>
								</div>
							</div>
							<div class="card-body pb-2 px-3">
								<div id="marketChart" class="market-line"></div>
							</div>
						</div>
					</div>
				</div>
				<div class="row">
                          <!-- temperature graph start -->
                            <div class="col-xl-4 col-lg-6">
                                <div class="card">
                                    <div class="card-header pb-0 border-0">
                                        <span class="p-3 mr-3 rounded bg-secondary">
                                            <img src="image/temperature.png"/>
                                        </span>
                                        <div class="mr-auto pr-3">
                                            <h4 class="text-black fs-20">Temperature</h4>
                                        </div>
                                    </div>
                                    <div class="card-body pb-0">
                                    <?php
                                      $query = "SELECT `temperature` FROM `sens_data` ";
                                     
                                      $result = mysqli_query($con, $query);

                                      while($row = mysqli_fetch_array($result))
                                      {
                                         $chart_data = $row["temperature"];
                                      }

                                      ?>
                                        
                                                      <div  id='myChart1'></div>
                                  
                                     <script>
                                        ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];

        
        
                                       var myConfig6 = {
                                        "type": "gauge",
                                              "scale-r": {
                                                "aperture": 200,
                                                "values": "0:100:20",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 40",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 40 && %v <= 70",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 70 && %v <= 80",
                                                      "background-color": "red"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
                                              "plot": {
                                                "csize": "5%",
                                                "size": "100%",
                                                "background-color": "#000000"
                                              },
                                              "series": [{
                                                "values": [<?php echo $chart_data; ?>]
                                              }]
                                            };
                                         
                                            zingchart.render({
                                              id: 'myChart1',
                                              data: myConfig6,
                                              values:'series',
                                              height: "250",
                                              width: "250"
                                            });
                                          </script>         
                        
                               </div>  
                            </div>
                          <!-- temperature graph end -->
                        </div> 
                        <div class="col-xl-4 col-lg-6">
                        <div class="card">
                            <div class="card-header pb-0 border-0">
                                <span class="p-3 mr-3 rounded bg-warning">
                                    <img src="image/ph-meter.png"/>
                                </span>
                                <div class="mr-auto pr-3">
                                    <h4 class="text-black fs-20">PH</h4>
                                </div>
                            </div>
                            <div class="card-body pb-0">
                            
                                <?php
                                  $query = "SELECT `ph` FROM `sens_data` ";
                                  $result = mysqli_query($con, $query);

                                  while($row = mysqli_fetch_array($result))
                                  {
                                     $chart_data =  $row["ph"];
                                  }

                                  ?>  
                              
                                  <div id='myChart'></div>

                                  <script>
                                    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];
                                    
                                    var myConfig6 = {
                                      "type": "gauge",
                                      "scale-r": {
                                        "aperture": 200,
                                        "values": "0:8:1",
                                        "center": {
                                          "size": 5,
                                          "background-color": "#66CCFF #FFCCFF",
                                          "border-color": "none"
                                        },
                                        "ring": { //Ring with Rules
                                          "size": 10,
                                          "rules": [{

                                              "rule": "%v >= 0 && %v <= 4",
                                              "background-color": "red"
                                            },
                                            {
                                              "rule": "%v >= 4 && %v <= 7",
                                              "background-color": "green"
                                            },
                                            {
                                              "rule": "%v >= 7 && %v <= 8",
                                              "background-color": "yellow"
                                            },
                                            
                                          ]
                                        }
                                      },
                                      "plot": {
                                        "csize": "5%",
                                        "size": "100%",
                                        "background-color": "#000000"
                                      },
                                      "series": [{
                                        "values": [<?php echo $chart_data; ?>]
                                      }]
                                    };
                                 
                                    zingchart.render({
                                      id: 'myChart',
                                      data: myConfig6,
                                      values:'series',
                                      height: "250",
                                      width: "250"
                                    });
                                  </script>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-4 ">
                      <div class="card">  
                            <div class="card-header pb-0 border-0">
                                <span class="p-3 mr-3 rounded bg-danger">
                                    <img src="image/moisture.png"/>
                                </span>
                                <div class="mr-auto pr-3">
                                    <h4 class="text-black fs-20">Moisture</h4>
                                </div>
                            </div>
                            <div class="card-body pb-0">
                                <?php
                                  $query = "SELECT `moisture` FROM `sens_data` ";
                                  $result = mysqli_query($con, $query);

                                while($row = mysqli_fetch_array($result))
                                {
                                 $chart_data =  $row["moisture"];
                                }

                                ?>  
                                   
                                  <div id='myChart2'></div>
                                  <script>
                                    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];
                                    
                                    var myConfig6 = {
                                      "type": "gauge",
                                      "scale-r": {
                                        "aperture": 200,
                                        "values": "0:100:10",
                                        "center": {
                                          "size": 5,
                                          "background-color": "#66CCFF #FFCCFF",
                                          "border-color": "none"
                                        },
                                        "ring": { //Ring with Rules
                                          "size": 10,
                                          "rules": [{

                                              "rule": "%v >= 0 && %v <= 30",
                                              "background-color": "red"
                                            },
                                            {
                                              "rule": "%v >= 30 && %v <= 70",
                                              "background-color": "green"
                                            },
                                            {
                                              "rule": "%v >= 70 && %v <= 100",
                                              "background-color": "blue"
                                            },
                                            
                                          ]
                                        }
                                      },
                                      "plot": {
                                        "csize": "5%",
                                        "size": "100%",
                                        "background-color": "#000000"
                                      },
                                      "series": [{
                                        "values": [<?php echo $chart_data; ?>]
                                      }]
                                    };
                                 
                                    zingchart.render({
                                      id: 'myChart2',
                                      data: myConfig6,
                                      values:'series',
                                      height: "250",
                                      width: "250"
                                    });
                                  </script>
                            </div>
                        </div>
                    </div>
                </div>   
				<div class="row">
					<div class="col-xl-6 col-xxl-12">
						<div class="row">
							<div class="col-sm-4">
								<div class="card">
									<div class="card-header border-0 pb-0">
										<h4 class="mb-0 fs-20 text-black">Ph Records</h4>
										
									</div>
									<div class="card-body p-3 pb-0">
										<div class="dropdown custom-dropdown d-block tbl-orders">
											<div class="btn  d-flex align-items-center border-0 order-bg rounded " data-toggle="dropdown">
												<svg width="46" height="46" viewBox="0 0 46 46" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M23.4169 0.00384777C10.7089 -0.226161 0.233857 9.88466 0.00384777 22.5831C-0.226161 35.2815 9.88466 45.7661 22.5831 45.9961C35.2815 46.2261 45.7661 36.1153 45.9961 23.4073C46.2261 10.7089 36.1153 0.224273 23.4169 0.00384777ZM22.6598 41.6834C12.3573 41.4918 4.12485 32.9622 4.31652 22.6598C4.49861 12.3573 13.0281 4.12485 23.3306 4.30694C33.6427 4.49861 41.8655 13.0281 41.6834 23.3306C41.5013 33.6331 32.9622 41.8655 22.6598 41.6834Z" fill="#374C98"/>
													<path d="M23.3038 6.22751C14.0555 6.06459 6.3981 13.4536 6.23518 22.7019C6.06267 31.9406 13.4517 39.598 22.7 39.7705C31.9483 39.9334 39.6057 32.5444 39.7686 23.3057C39.9315 14.0574 32.5521 6.40002 23.3038 6.22751ZM30.2136 32.7361H14.9564L16.8252 22.3952L14.6593 22.8457V21.0823L17.151 20.5552L18.7707 11.6615H24.8563L23.4763 19.2326L25.6039 18.7822V20.5456L23.1504 21.0535L21.732 28.8738H31.3445L30.2136 32.7361Z" fill="#374C98"/>
													
												</svg>
												<div class="text-left ml-3">
													<span class="d-block fs-16 text-black">Ph</span>
												</div>
												
											</div>
											
										</div>
										<div class="table-responsive">
											<table class="table text-center bg-info-hover tr-rounded order-tbl">
												<thead>
													<tr>
														<th class="text-left">Date/Time</th>
														<th class="text-center">Ph</th>
													</tr>
												</thead>
												<?php 
                                        $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
												<tbody>
													<tr>
														<td class="text-left"><?php echo $p['timestamp'] ?></td>
														<td><?php echo $p['ph'] ?></td>
														
													</tr>
												</tbody>
												<?php 
									            }
									            ?>
											</table>
										</div>
									</div>
									
								</div>	
							</div>
							<div class="col-sm-4">
								<div class="card">
									<div class="card-header border-0 pb-0">
										<h4 class="mb-0 text-black fs-20">Temperature records</h4>
									</div>
									<div class="card-body p-3 pb-0">
										<div class="dropdown custom-dropdown d-block tbl-orders">
											<div class="btn  d-flex align-items-center order-bg border-0 rounded" data-toggle="dropdown">
												<svg width="46" height="46" viewBox="0 0 46 46" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M23.4169 0.00384778C10.7089 -0.226162 0.233857 9.88467 0.00384778 22.5831C-0.226162 35.2816 9.88467 45.7662 22.5831 45.9962C35.2816 46.2262 45.7662 36.1153 45.9962 23.4073C46.2262 10.7089 36.1153 0.224274 23.4169 0.00384778ZM22.6598 41.6835C12.3573 41.4918 4.12485 32.9623 4.31653 22.6598C4.49862 12.3573 13.0281 4.12485 23.3306 4.30694C33.6427 4.49862 41.8656 13.0281 41.6835 23.3306C41.5014 33.6332 32.9623 41.8656 22.6598 41.6835Z" fill="#FF782C"/>
													<path d="M23.3019 6.22369C14.0536 6.06076 6.3962 13.4498 6.23327 22.6981C6.17864 25.6077 6.8773 28.3592 8.14427 30.7705H13.4163V14.2616C13.4163 13.2524 14.7877 12.9313 15.2334 13.837L23 29.5649L30.7667 13.838C31.2123 12.9313 32.5837 13.2524 32.5837 14.2616V30.7705H37.8395C39.0182 28.5298 39.7198 25.9997 39.7667 23.3019C39.9297 14.0536 32.5502 6.3962 23.3019 6.22369Z" fill="#FF782C"/>
													<path d="M30.667 31.7289V18.3672L23.8587 32.1534C23.5367 32.808 22.4624 32.808 22.1403 32.1534L15.333 18.3672V31.7289C15.333 32.2579 14.9046 32.6872 14.3746 32.6872H9.34223C12.3237 36.8763 17.1712 39.6632 22.6981 39.7667C28.4455 39.8683 33.5747 37.0507 36.6769 32.6872H31.6254C31.0954 32.6872 30.667 32.2579 30.667 31.7289Z" fill="#FF782C"/>
													
												</svg>
												<div class="text-left ml-3">
													<span class="d-block fs-16 text-black">Temperature</span>
												</div>
											</div>
											
										</div>
										<div class="table-responsive">
											<table class="table text-center bg-warning-hover tr-rounded order-tbl">
												<thead>
													<tr>
														<th class="text-left">Date/Time</th>
														<th class="text-center">Temp</th>
														
													</tr>
												</thead>
												<?php 
                                            $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                            while($p=mysqli_fetch_array($part))
                                            {
											?>
												<tbody>
													<tr>
														<td class="text-left"><?php echo $p['timestamp'] ?></td>
														<td><?php echo $p['temperature'] ?></td>
														
													</tr>
												</tbody>
												<?php 
									}
									?>
											</table>
										</div>
									</div>
								</div>
							</div>
							<div class="col-sm-4">
								<div class="card">
									<div class="card-header border-0 pb-0">
										<h4 class="mb-0 fs-20 text-black">Moisture Records</h4>
									</div>
									<div class="card-body p-3 pb-0">
										<div class="dropdown custom-dropdown d-block tbl-orders">
											<div class="btn  d-flex align-items-center border-0 order-bg rounded " data-toggle="dropdown">
												<svg width="46" height="46" viewBox="0 0 46 46" fill="none" xmlns="http://www.w3.org/2000/svg">
													<path d="M23.4169 0.00384778C10.7089 -0.226162 0.233857 9.88467 0.00384778 22.5831C-0.226162 35.2816 9.88467 45.7662 22.5831 45.9962C35.2816 46.2262 45.7662 36.1153 45.9962 23.4073C46.2262 10.7089 36.1153 0.224274 23.4169 0.00384778ZM22.6598 41.6835C12.3573 41.4918 4.12485 32.9623 4.31653 22.6598C4.49862 12.3573 13.0281 4.12485 23.3306 4.30694C33.6427 4.49862 41.8656 13.0281 41.6835 23.3306C41.5014 33.6332 32.9623 41.8656 22.6598 41.6835Z" fill="#FF782C"/>
													<path d="M23.3019 6.22369C14.0536 6.06076 6.3962 13.4498 6.23327 22.6981C6.17864 25.6077 6.8773 28.3592 8.14427 30.7705H13.4163V14.2616C13.4163 13.2524 14.7877 12.9313 15.2334 13.837L23 29.5649L30.7667 13.838C31.2123 12.9313 32.5837 13.2524 32.5837 14.2616V30.7705H37.8395C39.0182 28.5298 39.7198 25.9997 39.7667 23.3019C39.9297 14.0536 32.5502 6.3962 23.3019 6.22369Z" fill="#FF782C"/>
													<path d="M30.667 31.7289V18.3672L23.8587 32.1534C23.5367 32.808 22.4624 32.808 22.1403 32.1534L15.333 18.3672V31.7289C15.333 32.2579 14.9046 32.6872 14.3746 32.6872H9.34223C12.3237 36.8763 17.1712 39.6632 22.6981 39.7667C28.4455 39.8683 33.5747 37.0507 36.6769 32.6872H31.6254C31.0954 32.6872 30.667 32.2579 30.667 31.7289Z" fill="#FF782C"/>
													
												</svg>
												<div class="text-left ml-3">
													<span class="d-block fs-16 text-black">Moisture</span>
												</div>
												
											</div>
											
										</div>
										<div class="table-responsive">
											<table class="table text-center bg-info-hover tr-rounded order-tbl">
												<thead>
													<tr>
														<th class="text-left">Date/Time</th>
														<th class="text-center">Moisture</th>
													</tr>
												</thead>
												<?php 
                                               $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                               while($p=mysqli_fetch_array($part))
                                                {
											    ?>
												<tbody>
													<tr>
														<td class="text-left"><?php echo $p['timestamp'] ?></td>
														<td><?php echo $p['moisture'] ?></td>
														
													</tr>
												</tbody>
												<?php 
									            }
									            ?>
											</table>
										</div>
									</div>
									
								</div>	
							</div>
							
						</div>
					</div>
					<div class="col-xl-6 col-xxl-12">
						<div class="row">
							
							<div class="col-xl-12 mt-2">
								<div class="card">
									<div class="card-body">
										
										<div class="d-flex mb-3 mt-3 justify-content-between align-items-center">
											<h4 class="text-black fs-20 mb-0">Recent Contacts</h4>
										</div>
										<div class="testimonial-one px-4 owl-right-nav owl-carousel owl-loaded owl-drag">
											<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `register`")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
                                              $reg=mysqli_query($con,"SELECT * FROM `profile` ")or die(mysqli_error($con));
                                              $r=mysqli_fetch_array($reg);	
											?>
											<div class="items">
												<div class="text-center">
													<img class="mb-3 rounded" src="images/contacts/Untitled-1.jpg" alt="">
													<h5 class="mb-0"><a class="text-black" href="view-profile.php?id=<?php echo $p['id']?>"><?php echo $p['name'] ?></a></h5>
													<span class="fs-14"><?php echo $p['email'] ?></span>
												</div>
											</div>
											<?php
									    }
									    ?>
											
											
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->
		
		
		
		
		
		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
	
	<!-- Chart piety plugin files -->
    <script src="./vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Apex Chart -->
	<script src="./vendor/apexchart/apexchart.js"></script>
	
	<!-- Dashboard 1 -->
	
	<script src="./js/dashboard/dashboard-1.js"></script>
	<script src="./vendor/owl-carousel/owl.carousel.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>

    <script>
    ZC.LICENSE = ["569d52cefae586f634c54f86dc99e6a9", "b55b025e438fa8a98e32482b5f768ff5"];
    var myConfig9 = {
      "type": "gauge",
      "scale": {
        "size-factor": 0.7
      },
      "scale-2": {
        "size-factor": 1
      },
      "scale-3": {
        "size-factor": 1.4
      },
      "scale-r": {
                                                "aperture": 200,
                                                "values": "0:100:20",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 40",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 40 && %v <= 70",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 70 && %v <= 80",
                                                      "background-color": "red"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      "scale-r-2": {
                                                "aperture": 200,
                                                "values": "0:100:10",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 30",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 30 && %v <= 70",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 70 && %v <= 100",
                                                      "background-color": "blue"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      "scale-r-3": {
                                                "aperture": 200,
                                                "values": "0:8:1",
                                                "center": {
                                                  "size": 5,
                                                  "background-color": "#66CCFF #FFCCFF",
                                                  "border-color": "none"
                                                },
                                                "ring": { //Ring with Rules
                                                  "size": 10,
                                                  "rules": [{

                                                      "rule": "%v >= 0 && %v <= 4",
                                                      "background-color": "yellow"
                                                    },
                                                    {
                                                      "rule": "%v >= 4 && %v <= 7",
                                                      "background-color": "green"
                                                    },
                                                    {
                                                      "rule": "%v >= 7 && %v <= 8",
                                                      "background-color": "red"
                                                    },
                                                    
                                                  ]
                                                }
                                              },
      
      
      "series": [{
          "values": [<?php echo $chart_data1; ?>],
          "csize": "5%",
          "size": "90%"
        },
        {
          "values": [<?php echo $chart_data2; ?>],
          "scales": "scale-2,scale-r-2", //Specify which scale your data should plot to.
          "csize": "5%",
          "size": "90%"
        },
        {
          "values": [<?php echo $chart_data3; ?>],
          "scales": "scale-3,scale-r-3", //Specify which scale your data should plot to.
          "csize": "5%",
          "size": "90%"
        }
      ]
    };
 
    zingchart.render({
      id: 'myChart',
      data: myConfig9,
      height: "225",
      width: "350"
    });
  </script>
    
</body>
</html>