<?php
include('conn.php');
$uid=$_SESSION['userid'];

if(isset($_POST['submit']))
{
    $name=$_POST["name"];
    $phone=$_POST["phone"];
    $email=$_POST["email"];
    $address=$_POST["address"];
    $location=$_POST["location"];
    $experience=$_POST["experience"];
    $specialist=$_POST["specialist"];
    
    $query="SELECT * FROM `agronist` WHERE `email`='$email' or `phone`='$phone'";
    $qry=mysqli_query($con,$query)or die(mysqli_error($con));

  
    if(mysqli_num_rows($qry)<1)
    {
    
        $target_dir = 'image/';

            if($_FILES["image"]["name"] != "")
            {

                $path = $target_dir . basename($_FILES["image"]["name"]);
                $imageFileType = strtolower(pathinfo($path,PATHINFO_EXTENSION));
               // $move_photo = move_uploaded_file($_FILES["image"]["name"] .$path); 
            
    
                mysqli_query($con,"INSERT INTO `agronist`( `userid`,`name`, `phone`, `email`, `address`, `location`, `experience`, `specialist`,`profile`) VALUES ('$uid','$name','$phone','$email','$address','$location','$experience','$specialist','$path')")or die(mysqli_error($con));
            
                 ?> 
                  <script >
                    alert("registration successful..");
                    window.location="agronamist-profile.php";
                  </script>
                 <?php
        }    
    }
    
    else
    {
         ?> 
      <script >
        alert("user already available");
      </script>
     <?php
    }
 
}

 ?>

 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/lightgallery/css/lightgallery.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		


		
		
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="javascript:void(0)">App</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Profile</a></li>
					</ol>
                </div>
                <!-- row -->
                
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="profile-tab">
                                    <div class="custom-tab-1">
                                        <ul class="nav nav-tabs">
                                        	<li class="nav-item"><a href="#profile-settings" data-toggle="tab" class="nav-link active show">Create your profile</a>
                                            </li>
                                            
                                            
                                        </ul>
                                        <div class="tab-content">
                                        	<div id="profile-settings" class="tab-pane fade active show">
                                                <div class="pt-3">
                                                    <div class="settings-form">
                                                        
                                                        <form method="POST" enctype="multipart/form-data">
                                                            
                                                            <div class="form-row">
                                                                
                                                                <div class="form-group col-md-4">
                                                                    <label>Name</label>
                                                                    <input name="name" type="text" class="form-control" placeholder="Enter your name">
                                                                    
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label>Email</label>
                                                                    <input name="email" type="email" class="form-control" placeholder="hello@gmail.com">
                                                                    
                                                                </div>
                                                            </div>
                                                            <div class="form-row">
                                                                
                                                                <div class="form-group col-md-4">
                                                                    <label>Phone number</label>
                                                                    <input name="phone" type="text" class="form-control" placeholder="+91 8765890543">
                                                                    
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label>Address</label>
                                                                    <input name="address" type="text" class="form-control" placeholder="13/432 SS nagar">
                                                                    
                                                                </div>
                                                            </div>
                                                            <div class="form-row">
                                                                
                                                                <div class="form-group col-md-4">
                                                                    <label>Location</label>
                                                                    <input name="location" type="text" class="form-control" placeholder="Coimbatore">
                                                                    
                                                                </div>
                                                                <div class="form-group col-md-4">
                                                                    <label>Year of Experience</label>
                                                                    <input name="experience" type="text" class="form-control" placeholder="7 years">
                                                                    
                                                                </div>
                                                            </div>
                                                            <div class="form-group">
                                                                    <label>Profile</label>
                                                                    <input name="image" type="file" class="form-control" >
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label>Specialist</label>
                                                                    <input name="specialist" type="text" class="form-control" placeholder="about me">
                                                                    
                                                            </div>
                                                            
                                                            <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
									<!-- Modal -->
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->
</div>
        
    
    <!--**********************************
        Main wrapper end
    ***********************************-->
	
	<!--removeIf(production)-->
        
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<script src="./vendor/lightgallery/js/lightgallery-all.min.js"></script>
	<script>
		$('#lightgallery').lightGallery({
			thumbnail:true,
		});
	</script>
    
</body>

</html>