<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a  href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        
                    </li>
                    <li><a  href="map.php" aria-expanded="false">
							<i class="fa fa-map-o" aria-hidden="true"></i>
							<span class="nav-text">Distance Maps</span>
						</a>
                       
                    </li>

                    <li><a  href="field-data.php" aria-expanded="false">
							<i class="fa fa-envira" aria-hidden="true"></i>
							<span class="nav-text">Field Data</span>
						</a>
                        
                    </li>
                    <li><a  href="blueprint.php" aria-expanded="false">
							<i class="fa fa-spinner" aria-hidden="true"></i>
							<span class="nav-text">Yield Data</span>
						</a>
                        
                    </li>
                    <li><a  href="fielddata-gallery.php" aria-expanded="false">
							<i class="fa fa-picture-o" aria-hidden="true"></i>
							<span class="nav-text">Field Data gallery</span>
						</a>
                        
                    </li>

                    <li><a  href="gadgets-table.php" aria-expanded="false">
                           <i class="fa fa-table" aria-hidden="true"></i>
                            <span class="nav-text">Table</span>
                        </a>
                        
                    </li>
                 
                    <li><a  href="portofolio.php" aria-expanded="false">
						<i class="fa fa-user" aria-hidden="true"></i>
							<span class="nav-text">Profile</span>
						</a>   
                    </li>

                    <li><a  href="agronamist-details.php" aria-expanded="false">
						<i class="fa fa-handshake-o" aria-hidden="true"></i>
							<span class="nav-text">Agronamist details</span>
						</a>   
                    </li>

                    <li><a  href="page-chat.php" aria-expanded="false">
						<i class="fa fa-commenting-o" aria-hidden="true"></i>
							<span class="nav-text">Chat</span>
						</a>   
                    </li>

                    <li><a  href="faq.php" aria-expanded="false">
						<i class="fa fa-cogs" aria-hidden="true"></i>
							<span class="nav-text">FAQs</span>
						</a>   
                    </li>

                    <li><a  href="suggestion.php" aria-expanded="false">
						<i class="fa fa-thumbs-up" aria-hidden="true"></i>
							<span class="nav-text">Suggestion</span>
						</a>   
                    </li>
                </ul>
				
				
			</div>
        </div>