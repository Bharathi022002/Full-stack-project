<?php
include('conn.php');
$uid=$_SESSION['userid'];
$name=$_SESSION['name'];
if(isset($_POST['profile']))
{
	
	$area=$_POST["area"];
	$tree=$_POST["tree"];

    $query="INSERT INTO `blueprint`( `userid`,`name`, `area`, `total tree`) VALUES ('$uid','$name','$area','$tree')";
      $rs=mysqli_query($con,$query)or die(mysqli_error($con));
	
        for ($i=0; $i < count($_POST['yield']); $i++) 
        // for ($i=0; $i < count($_POST['MaterialName']); $i++) 

        {
           $yield=$_POST['yield'][$i];
           $condition=$_POST['condition'][$i];

           $query_material="INSERT INTO `blueprint-view`(`userid`, `yield`, `condition`, `date`) VALUES ('$uid','".$yield."','".$condition."',now())";
    
        $rs_material=mysqli_query($con,$query_material)or die(mysqli_error($con));

    if($rs)
    {
    ?>
    <script type="text/javascript">
        alert("Added successsfully");
        window.location="blueprint.php";
    </script>
    <?php
    }
        
    }
     
}
 ?>
<!-- html start -->
 <!DOCTYPE html>
<html lang="en">
<!-- head start --->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/lightgallery/css/lightgallery.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<!-- head end -- >
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		


		
		
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="javascript:void(0)">App</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Profile</a></li>
					</ol>
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="profile card card-body px-3 pt-3 pb-0">
                            <div class="profile-head">
                                
                                <?php 
                                $part=mysqli_query($con,"SELECT * FROM `register` where `id`='$uid'")or die(mysqli_error($con));
                                while($p=mysqli_fetch_array($part))
                                {
                                 ?>
                                <div class="profile-info">
									<div class="profile-photo">
										<img src="<?php echo $p["profile"]; ?>" alt="" width="70px" height="70px">
									</div>
									<div class="profile-details">
										<div class="profile-name px-3 pt-2">
											<h4 class="text-primary mb-0"><?php echo $p["name"]; ?></h4>
											
										</div>
										<div class="profile-email px-2 pt-2">
											<h4 class="text-muted mb-0"><?php echo $p["email"]; ?></h4>
											
										</div>
										
									</div>
                                </div>
                                <?php
                            }
                            ?>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- row end-->
                <!-- row start -->
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="profile-tab">
                                    <div class="custom-tab-1">
                                        <ul class="nav nav-tabs">
                                        	
                                            <li class="nav-item"><a href="#about-me" data-toggle="tab" class="nav-link active show">About Yield</a>
                                            </li>
                                            
                                        </ul>
                                        <div class="tab-content">
                                            <div id="profile-settings" class="tab-pane fade active show">
                                                <div class="pt-3">
                                                    <div class="settings-form">
                                                        <form method="POST">
                                                            
                                                            <div class="form-group">
                                                                <label>Area in acre</label>
                                                                <input type="text" name="area" placeholder="7 acre" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                    <label>Total no of trees</label>
                                                                    <input name="tree" type="text" class="form-control" placeholder="7 trees">
                                                                    
                                                                
                                                            </div>
                                                            
                                                            <div class="form-group">
                            
                                                               <div class="pull-right form-inline">
                                                                <hr>      
                                                                    <input type="button" id="add" value="Add" class="btn btn-info">
                                                               </div><br>
                                                                <table class="table table-bordered">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>S.No</th>
                                                                            <th>Yield</th>
                                                                            <th>Condition</th>
                                                                            
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="tbody">

                                                                            
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </div>
                                                            
                                                            <button class="btn btn-primary" type="submit" name="profile">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
									<!-- Modal -->
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- row end -->
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

        
    
    <!--**********************************
        Main wrapper end
    ***********************************-->
	
	<!--removeIf(production)-->
        
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->

    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<script src="./vendor/lightgallery/js/lightgallery-all.min.js"></script>
	<script>
		$('#lightgallery').lightGallery({
			thumbnail:true,
		});
	</script>
    <!-- <script type="text/javascript">   
   
    $(document).ready(function(){
            var i=1;


        //  $('#myForm').submit(function(e) {
        //     e.preventDefault();
        //     if(!$('#phonenumber').val().match('[0-9]{10}'))  {
        //         alert("Please put 10 digit mobile number");
        //         return;
        //     }  

        // });
            $(document).on('click','#add',function(){
                 
 
                var output=`
                <tr>
                    <td>
                        `+(i)+`
                    </td>
                    <td>

<input type="text"  class="form-control" name="MaterialName[]"  required />
 </td> 
 <td>
<input type="number"  class="form-control" min="0" name="Quantity[]"  required />
 </td>
 <td>
<input type="text"  class="form-control" name="customersideprob[]"  />
 </td>
 <td>
 <select name="servicetype[]" class="form-control" >
                                <option value="Service">Service</option>
                                <option value="Reservice">Reservice</option>
                                
                                </select>
 </td>                               
 <td>
<input type="text"  class="form-control" name="additional_remarks[]"  />
 </td>
     <td>
<i class="fa fa-times remove text-danger"  ></i>
                    </td>
                </tr>
                `;
                
                  i++;
                $("#tbody").append(output);
                
            });
             $(document).on('click','.remove',function(){
                $($(this).closest("tr")).remove();
                i--;
            })
        });
</script> -->


<!-- add option script -->
    <script type="text/javascript">   
   
    $(document).ready(function(){
            var i=1;

            $(document).on('click','#add',function(){
                 
 
                var output=`
                <tr>
                    <td>
                        `+(i)+`
                    </td>
                    <td>

                 <input type="text"  class="form-control" name="yield[]"  required />
                  </td> 
                   <td>
                 <input type="text"  class="form-control"  name="condition[]"  required />
                </td>
                <td>
                <i class="fa fa-times remove text-danger"  ></i>
                    </td>
     
                </tr>
                `;
                
                  i++;
                $("#tbody").append(output);
                
            });
             $(document).on('click','.remove',function(){
                $($(this).closest("tr")).remove();
                i--;
            })
        });
</script>
<!-- add script end -->
		
</body>

</html>