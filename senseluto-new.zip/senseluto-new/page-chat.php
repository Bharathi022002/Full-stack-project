<?php 
include("conn.php");
$uid=$_SESSION['userid'];
$image=$_SESSION['image'];

if(isset($_POST['click']))
{
    $chat=$_POST["chat"];
    
    mysqli_query($con,"INSERT INTO `chat`( `userid`,`profile`, `chat`) VALUES ('$uid','$image','$chat')")or die(mysqli_error($con));
   
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
    <meta name="viewport" content="width=device-width,initial-scale=1">
	<meta name="description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:title" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:description" content="Zenix - Crypto Admin Dashboard" />
	<meta property="og:image" content="https://zenix.dexignzone.com/xhtml/social-image.png" />
	<meta name="format-detection" content="telephone=no">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
			
		<!--**********************************
            Header start
        ***********************************-->
        <?php include "header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body chat-body">
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-12">
						<div class="card">
							<div class="card-body chat-wrapper p-0">
								<div class="chat-hamburger">
									<span></span>
									<span></span>
									<span></span>
								</div>
								<div class="chat-left-sidebar">
									<div class="d-flex chat-fix-search align-items-center">
										<img src="<?php echo $_SESSION['image']; ?>" alt="" class="rounded-circle mr-3">
										<div class="input-group message-search-area">
											<input type="text" class="form-control" placeholder="Search here..">
											<div class="input-group-append">
												<button class="input-group-text"><i class="flaticon-381-search-2"></i></button>
											</div>
										</div>
									</div>
									<div class="card-action card-tabs">
										<ul class="nav nav-tabs style-3" role="tablist">
											<li class="nav-item">
												<a class="nav-link active" data-toggle="tab" href="#AllMessage" role="tab" aria-selected="false">
													All Users
												</a>
											</li>
											
										</ul>
									</div>
									<div class="card-body message-bx px-0 pt-3" >
										<div class="tab-content dz-scroll" id="message-bx">
											<div class="tab-pane fade show active" id="AllMessage" role="tabpanel">
												<?php 
												
				                                $reg=mysqli_query($con,"SELECT * FROM `register` where `id` != '$uid'")or die(mysqli_error($con));
				                                while($p=mysqli_fetch_array($reg))
				                                {
										         ?>
												<div class="chat-list-area" data-chat="person1">
													<div class="image-bx">
														<img src="<?php echo $p["profile"]; ?>" alt="" class="rounded-circle img-1">
														<span class="active"></span>
													</div>
													<div class="info-body">
														<div class="d-flex">
															<h6 class="text-black user-name mb-0 font-w600 fs-16" data-name="Harry Marten"><?php echo $p["name"]; ?></h6>
															
														</div>
													</div>
												</div>
												<?php
											    }
											    ?>
												
											</div>
										</div>
									</div>
								</div>
								<div class="chart-right-sidebar">
									<div class="message-bx chat-box">
										<form method="POST" enctype="multipart/form-data">
										<div class="chat-box-area dz-scroll"  style="background-image:url('images/chat-bg.png');">
											
											<div data-chat="person1" class="chat active-chat">
											  <?php 
											  $uid=$_SESSION['userid'];
						                      $part=mysqli_query($con,"SELECT * FROM `chat`")or die(mysqli_error($con));
						                      while($p=mysqli_fetch_array($part))
						                      {
			
						                      if($p["userid"] == "$uid")
                                              {
						                      ?>
												<div class="media mb-4 received-msg  justify-content-start align-items-start">
													<div class="image-bx mr-sm-3 mr-2">
														<img src="<?php echo $_SESSION['image']; ?>" alt="" class="rounded-circle img-1">
													</div>
													<div class="message-received">
														<p class="mb-1">
															<?php echo $p["chat"]; ?>
														</p>
														<span class="fs-12 text-black">4.30 AM</span>
													</div>
												</div>
												<?php 
											    }
											  else
											  {
												?>
												<div class="media mb-4  justify-content-end align-items-end">
													<div class="message-sent">
														<p class="mb-1">
															<?php echo $p["chat"]; ?>
														</p>
														<span class="fs-12 text-black">9.30 AM</span>
													</div>
													<div class="image-bx ml-sm-3 ml-2 mb-4">
														<img src="<?php echo $p["profile"]; ?>" alt="" class="rounded-circle img-1">
													</div>
												</div>
												<?php 
										      }
										      }
										      ?>
											</div>
											  
										</div>

										<div class="card-footer border-0 type-massage">
											<div class="input-group">
												<input class="form-control" name="chat" placeholder="Type message..." />
												<div class="input-group-append"> 
													<button type="submit" name="click" class="send-btn btn-primary btn">SEND</button>
												</div>
											</div>
										</div>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->
		
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
	
	<!-- Chart piety plugin files -->
    <script src="./vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Apex Chart -->
	<script src="./vendor/apexchart/apexchart.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="./js/dashboard/chat.js"></script>
	
	<script src="./vendor/owl-carousel/owl.carousel.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
    
    

</body>
</html>