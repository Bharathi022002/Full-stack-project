<?php
include('conn.php');

$uid=$_SESSION['userid'];
$image=$_SESSION['image'];
$name=$_SESSION['name'];
$email=$_SESSION['email'];

if(isset($_POST['upload']))
{

	 	$target_dir = "image/field/";
       if($_FILES['filename']['name']!= "")
	   {

		$doc_path = $target_dir . basename($_FILES["filename"]["name"]);
		$imageFileType = strtolower(pathinfo($doc_path,PATHINFO_EXTENSION));
		$move_photo = move_uploaded_file($_FILES["filename"]["tmp_name"], $doc_path);	
        
   

    
        mysqli_query($con,"INSERT INTO `post`(`name`, `userid`, `photo`) VALUES ('$name','$uid','$doc_path')")or die(mysqli_error($con));
		
		
		
		?> 
      <script >
        alert("Posted..");
      </script>
     <?php

     
    }
	else
	{
	?> 
      <script >
        alert("Failed to Update..");
      </script>
     <?php
	}
    
 }


?>
<!-- html start -->
<!DOCTYPE html>

<html lang="en">
<!-- head start -->
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link href="./vendor/lightgallery/css/lightgallery.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">

</head>
<!-- head end -->
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
      <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		


		
		
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
       <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Field Gallery</a></li>
					</ol>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
							<div class="card-header">
								<h4 class="card-title">Field Gallery</h4>
							</div>
							<form method="post" enctype='multipart/form-data' >
							<div class="card-header">
								<h4 class="card-title">Photo</h4>
								<input type="file" class="form-control" name="filename" >
								<button class="btn btn-primary" type="submit" name="upload">Submit</button>
							</div>
						</form>
							<div class="card-body pb-1">
								<div id="lightgallery" class="row">
									<?php 
                                $part=mysqli_query($con,"SELECT * FROM `post` ")or die(mysqli_error($con));
                               while($p=mysqli_fetch_array($part))
                               {
                                ?>
									<a href="<?php echo $p["photo"]; ?>" data-exthumbimage="<?php echo $p["photo"]; ?>" data-src="<?php echo $p["photo"]; ?>" class="col-lg-3 col-md-6 mb-4">
										<img src="<?php echo $p["photo"]; ?>" width=80% height=80%/>
									</a>
									<?php
							}
							?>
								</div>
								
							</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	
    <script src="./vendor/lightgallery/js/lightgallery-all.min.js"></script>
	<script>
		$('#lightgallery').lightGallery({
			loop:true,
			thumbnail:true,
			exThumbImage: 'data-exthumbimage'
		});
	</script>

</body>

</html>