<?php
    include("config.php");
?>
<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/bootstrap-theme.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">
    <script src="http://code.jquery.com/jquery-1.10.1.min.js"></script>
    <script src="http://code.jquery.com/jquery-migrate-1.2.1.min.js"></script>    
    <script src="js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container header">
        <div class="col-lg-12">
            <a class="brand" href="#"><img src="img/a1.png"></a>
        </div>
    </div>
        <div class="container-fluid">
            <?php include("menu.php")?>
        </div>
   <div class="container ">
        <div class="row">
            <div class="col-sm-12">
                <br>
                <h2>Recent Posts</h2>
               <?php
                $sel_latest_qry=mysql_query("select form_dtl.*, user_dtl.name from form_dtl inner join user_dtl on form_dtl.user_id=user_dtl.user_id order by created_dtm limit 0,10");
                while($sel_latest_qry_arr=mysql_fetch_array($sel_latest_qry))
                {
                ?>
                <blockquote>
  <a href="view-post.php?id=<?=$sel_latest_qry_arr['f_id']?>"><p><?=$sel_latest_qry_arr['title']?></p></a>
  <p>By <?=$sel_latest_qry_arr['name']?> On <?=$sel_latest_qry_arr['created_dtm']?></p>
</blockquote>
                <?
                }
              ?>
               
            </div>
        </div>
    </div>
</body>
</html>
