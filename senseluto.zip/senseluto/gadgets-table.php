<?php
include("conn.php");
$uid=$_SESSION['userid'];
$name=$_SESSION['name'];
$gid=$_SESSION['gid'];


$temp_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";
$data_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
        
        
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
       <?php include "sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
        
        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
            <div class="container-fluid">
                <div class="row">
                    
                    
                    <div class="col-xl-4 col-xxl-12 col-lg-12">
                        <div class="card">
                            <div class="card-header bg-white">
                                <div class="d-flex align-items-center mr-3">
                                    <span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-warning">
                                        <img src="https://img.icons8.com/ios/30/ffffff/ph-meter.png"/>
                                    </span>
                                    <h4 class="fs-20 text-black mb-0"> Data Log </h4>
                                </div>
                                
                            </div>
                            <div class="card-body p-0">
                                <div class="table-responsive">
                                    <table class="table shadow-hover">
                                        <thead>
                                            <tr>
                                                <th><span class="font-w600 text-black fs-16">S.No</span></th>
                                                <th><span class="font-w600 text-black fs-16">Temperature</span></th>
                                                <th><span class="font-w600 text-black fs-16">Moisture</span></th>
                                                <th><span class="font-w600 text-black fs-16">ph</span></th>
                                            </tr>
                                        </thead>
                                        <?php 
                                        $part=mysqli_query($con,$data_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
                                            //ph 
                                                if( $p['ph']  > 0 and  $p['ph'] <4 )
                                                {
                                                    $color="red";
                                                }
                                                
                                                elseif($p['ph'] >=4 and $p['ph']  <7)
                                                {
                                                    $color="green";

                                                }
                                                
                                                else
                                                {
                                                    $color="yellow";
                                                }


                                                
                                            //moisture     
                                                if(  $p['moisture'] >0 and $p['moisture']  < 30 )
                                                {
                                                    $color2="red";
                                                }
                                                
                                                elseif( $p['moisture']>=30 and $p['moisture']  <70 )
                                                {
                                                    $color2="green";

                                                }
                                                
                                                else
                                                {
                                                    $color2="blue";
                                                }

                                            //temperature    
                                                if(  $p['temperature']>0 and $p['temperature']  < 40 )
                                                {
                                                    $color1="yellow";
                                                }
                                                
                                                elseif( $p['temperature']>=40 and $p['temperature']  <80 )
                                                {
                                                    $color1="green";

                                                }
                                                
                                                else
                                                {
                                                    $color1="red";
                                                }

                                            ?>
                                        <tbody>
                                            <tr>
                                                <td>
                                                    <span class="fs-14"><?php echo $p['id'] ?></span>
                                                </td>
                                                <td style="background-color: <?=$color1; ?>;">
                                                    <span class="fs-14"><?php echo $p['temperature'] ?></span>
                                                </td>
                                                <td style="background-color: <?=$color2; ?>;">
                                                    <span class="fs-14"><?php echo $p['moisture'] ?></span>
                                                </td>
                                                <td style="background-color: <?=$color; ?>;">
                                                    <span class="fs-14"><?php echo $p['ph'] ?></span>
                                                </td>
                                            </tr>
                                        </tbody>
                                        <?php 
                                    }
                                    ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
    <script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>
</body>
</html>