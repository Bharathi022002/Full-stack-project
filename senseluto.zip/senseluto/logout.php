<?php
include('conn.php');


session_unset();
session_destroy();
?>

<script>
	alert("logged out");
	window.location="page-login.php";
</script>