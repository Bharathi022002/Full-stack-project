<?php
include("conn.php");



  if(isset($_SESSION['userid']))
                    {
                                if($_SESSION['userid']!='')
								{
								
								$uid=$_SESSION['userid'];
								$image=$_SESSION['image'];
								$name=$_SESSION['name'];

								}
								
					}
					else{

	
									?>
									<script type="text/javascript">
										window.location="page-login.php";
									</script>
									<?php
									}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <?php include "header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					<div class="col-xl-6 col-xxl-12">
						<div class="row">
							<!-- ph avg -->
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-success mr-md-4 mr-3">
												<img src="https://img.icons8.com/external-tal-revivo-filled-tal-revivo/48/000000/external-manual-ph-metre-indicator-dial-isolated-on-a-white-background-labs-filled-tal-revivo.png"/>
											</span>
											<div class="media-body">
												<form method="POST">
												<p class="fs-14 mb-2">PH</p>
												<?php 
												
                                                $reg=mysqli_query($con,"SELECT AVG(`ph`) as aph FROM `sens_data` ")or die(mysqli_error($con));
                                                while($p=mysqli_fetch_array($reg))
                                                {
												?>
												<span class="title text-black font-w600"><?php echo number_format((float)$p['aph'], 2, '.', '');  ?></span>
												<?php
											}
											?>
											  </form>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-success" style="width: 42%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-success"></div>
								</div>
							</div>
							<!-- end -->

							<!-- temperature avg -->
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-secondary  mr-md-4 mr-3">
												<img src="https://img.icons8.com/fluency-systems-regular/48/000000/temperature--v1.png"/>
											</span>
											<div class="media-body">
												<form method="POST">
												<p class="fs-14 mb-2">Temperature</p>
												<?php 
												
                                                $reg=mysqli_query($con,"SELECT AVG(`temperature`) as temp FROM `sens_data` ")or die(mysqli_error($con));
                                                while($p=mysqli_fetch_array($reg))
                                                {
												?>
												<span class="title text-black font-w600"><?php echo number_format((float)$p['temp'], 2, '.', '');  ?></span>
												<?php
											}
											?>
											  </form>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-secondary" style="width: 82%; height:5px;" role="progressbar">
												<span class="sr-only"></span>
											</div>
										</div>
									</div>
									<div class="effect bg-secondary"></div>
								</div>
							</div>
							<!-- end -->

							<!-- moisture avg -->
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-danger mr-md-4 mr-3">
												<img src="https://img.icons8.com/ios-filled/50/000000/moisture.png"/>
											</span>
											<div class="media-body">
												<form method="POST">
												<p class="fs-14 mb-2">Moisture</p>
												<?php 
												
                                                $reg=mysqli_query($con,"SELECT AVG(`moisture`) as moist FROM `sens_data` ")or die(mysqli_error($con));
                                                while($p=mysqli_fetch_array($reg))
                                                {
												?>
												<span class="title text-black font-w600"><?php echo number_format((float)$p['moist'], 2, '.', '');  ?> </span>
												<?php
											}
											?>
											  </form>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-danger" style="width: 90%; height:5px;" role="progressbar">
												<span class="sr-only">42% Complete</span>
											</div>
										</div>
									</div>
									<div class="effect bg-danger"></div>
								</div>
							</div>
							<!--end -->

							<!--humidity start -->
							<div class="col-sm-6">
								<div class="card avtivity-card">
									<div class="card-body">
										<div class="media align-items-center">
											<span class="activity-icon bgl-warning  mr-md-4 mr-3">
												<img src="https://img.icons8.com/ios-glyphs/48/000000/humidity.png"/>
											</span>
											<div class="media-body">
												<p class="fs-14 mb-2">Humidity</p>
												<span class="title text-black font-w600">18:34:21”</span>
											</div>
										</div>
										<div class="progress" style="height:5px;">
											<div class="progress-bar bg-warning" style="width: 42%; height:5px;" role="progressbar">
												<span class="sr-only">42% Complete</span>
											</div>
										</div>
									</div>
									<div class="effect bg-warning"></div>
								</div>
							</div>
							<!-- end -->
						</div>
					</div>
					<!-- temperature graph -->
					<div class="col-xl-6 col-xxl-12">
						<div class="card">
							<div class="card-header d-sm-flex d-block pb-0 border-0">
								<div class="mr-auto pr-3 mb-sm-0 mb-3">
									<h4 class="text-black fs-20">Plan List</h4>
								</div>
								<div class="dropdown mb-3 show">
									<button type="button" class="btn rounded btn-light" data-toggle="dropdown" aria-expanded="true">
										<img src="https://img.icons8.com/windows/32/4a90e2/temperature-high.png"/>
										Temperature
										<svg class="ml-2" width="14" height="8" viewBox="0 0 14 8" fill="none" xmlns="http://www.w3.org/2000/svg">
											<path d="M1 0.999999L7 7L13 1" stroke="#0B2A97" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
										</svg>
									</button>
									<div class="dropdown-menu dropdown-menu-right">
										<a class="dropdown-item" href="javascript:void(0);">Edit</a>
										<a class="dropdown-item" href="javascript:void(0);">Delete</a>
									</div>
								</div>
							</div>
							<?php
                             $qur=mysqli_query($con,"SELECT * FROM `sens_data` WHERE `timestamp`='2021-12-29' ")or die(mysqli_error($con));
                            if($r=mysqli_fetch_array($qur))
                            {
                            
							?>
							<div class="card-body pt-0 pb-0">
								<div id="chartBar"></div>
							</div>
							<?php 
						
					        }
						?>
						</div>
					</div>
					<!-- end -->

					<!-- user details displaying -->
					<div class="col-xl-12 col-xxl-12">
						<div class="row">
							<div class="col-xl-12">	
								<div class="card">
									<div class="card-header d-sm-flex d-block pb-0 border-0">
										<div class="mr-auto pr-3">
											<h4 class="text-black font-w600 fs-20">Senseluto graph</h4>
										</div>
									</div>
									<div class="card-body pt-2">
										
										<div class="testimonial-one owl-carousel">
											<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `register` ")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
											<div class="items">
												<div class="card text-center">
													<div class="card-body">
														<img src="<?php echo $p['profile'] ?>" alt="">
														<h5 class="fs-16 font-w500 mb-1"><a href="app-profile.html" class="text-black"><?php echo $p['name'] ?></a></h5>
														<p class="fs-14"><?php echo $p['email'] ?></p>
														<div class="d-flex align-items-center justify-content-center">
															<a href="app-profile.php" class="btn-link fs-14">View Profile</a>
														</div>
													</div>
												</div>
											</div>
											<?php
									}
									?>
										</div>
										
									
									</div>
								</div>
							</div>
							
						</div>
					</div>
					<!-- end -->
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<script src="./vendor/owl-carousel/owl.carousel.js"></script>
	
	<!-- Chart piety plugin files -->
    <script src="./vendor/peity/jquery.peity.min.js"></script>
	
	<!-- Apex Chart -->
	<script src="./vendor/apexchart/apexchart.js"></script>
	
	<!-- Dashboard 1 -->
	<script src="./js/dashboard/workout-statistic.js"></script>
	<script>
		function carouselReview(){
			/*  testimonial one function by = owl.carousel.js */
			jQuery('.testimonial-one').owlCarousel({
				loop:true,
				autoplay:true,
				margin:30,
				nav:false,
				dots: false,
				left:true,
				navText: ['<i class="fa fa-chevron-left" aria-hidden="true"></i>', '<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
				responsive:{
					0:{
						items:1
					},
					484:{
						items:2
					},
					882:{
						items:3
					},	
					1200:{
						items:2
					},			
					
					1540:{
						items:3
					},
					1740:{
						items:4
					}
				}
			})			
		}
		jQuery(window).on('load',function(){
			setTimeout(function(){
				carouselReview();
			}, 1000); 
		});
	</script>
</body>
</html>