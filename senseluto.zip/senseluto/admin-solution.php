<?php
include('conn.php');


$uid=$_SESSION['userid'];
$name=$_SESSION['name'];

if(isset($_POST['solution']))
{
    
    $problem=$_POST["problem"];
    
    $query="INSERT INTO `solution`(`userid`, `name`, `problem`, `date`) VALUES ('$uid','$name','$problem',now())";
      $rs=mysqli_query($con,$query)or die(mysqli_error($con));
    
        // for ($i=0; $i < count($_POST['problem']); $i++) 
        // // for ($i=0; $i < count($_POST['MaterialName']); $i++) 

        // {

        //    $query_material="INSERT INTO `solution`(`userid`, `name`, `problem`, `date`) VALUES ('$uid','$name','".$problem."',now())";
    
        // $rs_material=mysqli_query($con,$query_material)or die(mysqli_error($con));

    if($rs)
    {
    ?>
    <script type="text/javascript">
        alert("Added successsfully");
    </script>
    <?php
    }
        
    // }
     
}
 ?>

 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="./vendor/lightgallery/css/lightgallery.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
        
        


        
        
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">App</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Profile</a></li>
                    </ol>
                </div>
                <!-- row -->
                
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="profile-tab">
                                    <div class="custom-tab-1">
                                        
                                        <div class="tab-content">
                                            <div id="profile-settings" class="tab-pane fade active show">
                                                <div class="pt-3">
                                                    <div class="settings-form">
                                                        <form method="POST">
                                                            <?php 
                                                            $part=mysqli_query($con,"SELECT * FROM `solution`")or die(mysqli_error($con));
                                                            while($p=mysqli_fetch_array($part))
                                                            { 
                                                                ?>

                                                            <!--**********************************
                                                                forum question display
                                                            ***********************************-->
                                                            <div class="form-group">
                                                                <label><h4><?php echo $p["problem"]; ?></h4></label>

                                                                <input type="text" name="problem"  class="form-control">
                                                                <input type="text" name="problem"  class="form-control">
                                                            </div>
                                                            <!--**********************************
                                                                forum end
                                                            ***********************************-->
                                                            <?php
                                                            }
                                                            ?>
                                                            
                                                            <!-- <div class="form-group">
                            
                                                               <div class="pull-right form-inline">
                                                                <hr>      
                                                                    <input type="button" id="add" value="Add" class="btn btn-info">
                                                               </div><br>
                                                                <table class="table table-bordered">
                                                                    <thead>
                                                                        <tr>
                                                                            <th>S.No</th>
                                                                            <th>Problems</th>
                                                                            
                                                                        </tr>
                                                                    </thead>
                                                                    <tbody id="tbody">

                                                                            
                                                                        
                                                                    </tbody>
                                                                </table>
                                                            </div> -->
                                                            
                                                            <button class="btn btn-primary" type="submit" name="solution">Post</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
                                    <!-- Modal -->
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        
        
    
    
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->

    <script src="./vendor/global/global.min.js"></script>
    <script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>
    <script src="./vendor/lightgallery/js/lightgallery-all.min.js"></script>
    <script>
        $('#lightgallery').lightGallery({
            thumbnail:true,
        });
    </script>
    <!-- <script type="text/javascript">   
   
    $(document).ready(function(){
            var i=1;


        //  $('#myForm').submit(function(e) {
        //     e.preventDefault();
        //     if(!$('#phonenumber').val().match('[0-9]{10}'))  {
        //         alert("Please put 10 digit mobile number");
        //         return;
        //     }  

        // });
            $(document).on('click','#add',function(){
                 
 
                var output=`
                <tr>
                    <td>
                        `+(i)+`
                    </td>
                    <td>

<input type="text"  class="form-control" name="MaterialName[]"  required />
 </td> 
 <td>
<input type="number"  class="form-control" min="0" name="Quantity[]"  required />
 </td>
 <td>
<input type="text"  class="form-control" name="customersideprob[]"  />
 </td>
 <td>
 <select name="servicetype[]" class="form-control" >
                                <option value="Service">Service</option>
                                <option value="Reservice">Reservice</option>
                                
                                </select>
 </td>                               
 <td>
<input type="text"  class="form-control" name="additional_remarks[]"  />
 </td>
     <td>
<i class="fa fa-times remove text-danger"  ></i>
                    </td>
                </tr>
                `;
                
                  i++;
                $("#tbody").append(output);
                
            });
             $(document).on('click','.remove',function(){
                $($(this).closest("tr")).remove();
                i--;
            })
        });
</script> -->
    <script type="text/javascript">   
   
    $(document).ready(function(){
            var i=1;

            $(document).on('click','#add',function(){
                 
 
                var output=`
                <tr>
                    <td>
                        `+(i)+`
                    </td>
                    <td>

                 <input type="text"  class="form-control" name="problem[]"  required />
                  </td> 
                <td>
                <i class="fa fa-times remove text-danger"  ></i>
                    </td>
     
                </tr>
                `;
                
                  i++;
                $("#tbody").append(output);
                
            });
             $(document).on('click','.remove',function(){
                $($(this).closest("tr")).remove();
                i--;
            })
        });
</script>
        
</body>

</html>