-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 28, 2021 at 11:27 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `senseluto`
--

-- --------------------------------------------------------

--
-- Table structure for table `sens_data`
--

CREATE TABLE `sens_data` (
  `id` int(255) NOT NULL,
  `n` longtext NOT NULL,
  `p` longtext NOT NULL,
  `k` longtext NOT NULL,
  `ph` longtext NOT NULL,
  `temperature` longtext NOT NULL,
  `moisture` longtext NOT NULL,
  `timestamp` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sens_data`
--

INSERT INTO `sens_data` (`id`, `n`, `p`, `k`, `ph`, `temperature`, `moisture`, `timestamp`) VALUES
(1, '242', '76', '251', '10.40', '60', '64.70', '2021-08-05 00:49:21'),
(2, '245', '77', '242', '10.60', '11.00', '65.00', '2021-08-04 00:49:55'),
(3, '242', '75', '240', '10.50', '10.80', '64.70', '2021-08-04 00:50:30'),
(4, '247', '75', '238', '10.20', '10.80', '65.10', '2021-08-04 00:51:04'),
(5, '251', '78', '249', '10.70', '10.80', '65.80', '2021-08-04 00:51:38'),
(6, '249', '78', '3', '10.40', '10.60', '66.50', '2021-08-04 00:52:13'),
(7, '242', '76', '245', '10.30', '10.80', '66.20', '2021-08-04 00:52:47'),
(8, '247', '76', '242', '10.60', '10.70', '66.60', '2021-08-04 00:53:22'),
(9, '254', '81', '245', '11.00', '10.60', '66.90', '2021-08-04 00:53:56'),
(10, '254', '81', '251', '10.50', '10.70', '66.90', '2021-08-04 00:54:20'),
(11, '245', '78', '242', '10.60', '14.10', '82.60', '2021-08-04 06:45:53'),
(12, '0', '80', '3', '11.20', '14.20', '82.60', '2021-08-04 06:46:27'),
(13, '254', '80', '0', '10.80', '14.00', '82.60', '2021-08-04 06:47:02'),
(14, '0', '78', '3', '11.00', '14.20', '82.60', '2021-08-04 06:47:36'),
(15, '5', '82', '251', '11.10', '14.10', '82.60', '2021-08-04 06:48:11'),
(16, '254', '77', '249', '11.00', '14.30', '82.60', '2021-08-04 06:48:45'),
(17, '249', '79', '245', '11.00', '14.40', '82.60', '2021-08-04 06:49:19'),
(18, '10', '84', '8', '11.40', '14.30', '82.60', '2021-08-04 06:49:54'),
(19, '251', '78', '247', '10.60', '14.70', '82.60', '2021-08-04 06:50:28'),
(20, '251', '79', '249', '10.60', '14.80', '82.60', '2021-08-04 06:51:02'),
(21, '242', '78', '245', '10.60', '14.90', '82.60', '2021-08-04 06:51:37'),
(22, '5', '83', '3', '11.00', '14.90', '82.60', '2021-08-04 06:52:11'),
(23, '5', '80', '5', '10.70', '14.90', '82.60', '2021-08-05 06:52:46'),
(24, '251', '81', '247', '11.30', '14.80', '82.60', '2021-08-04 06:53:20'),
(25, '0', '78', '3', '10.80', '15.10', '82.60', '2021-08-05 06:53:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `sens_data`
--
ALTER TABLE `sens_data`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `sens_data`
--
ALTER TABLE `sens_data`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23644;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
