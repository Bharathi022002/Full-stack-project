<?php
header('Content-Type: application/json');
session_start();
$gid=$_SESSION['gid'];

$conn = mysqli_connect("localhost","root","","senseluto") or die("error");

$sqlQuery = "SELECT * FROM `sens_data` where   `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC limit 4";

$result = mysqli_query($conn,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>