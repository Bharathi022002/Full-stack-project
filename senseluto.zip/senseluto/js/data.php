<?php
header('Content-Type: application/json');

$conn = mysqli_connect("localhost","root","","senseluto");

$sqlQuery = "SELECT * FROM `sens_data` ORDER BY `sens_data`.`timestamp` DESC limit 3";

$result = mysqli_query($conn,$sqlQuery);

$data = array();
foreach ($result as $row) {
	$data[] = $row;
}

mysqli_close($conn);

echo json_encode($data);
?>