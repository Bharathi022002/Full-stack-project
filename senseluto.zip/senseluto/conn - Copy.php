<?php

session_start();
$con=mysqli_connect("localhost","root","","sens_data")or die("connection error");


$title="SENSELUTO - SOIL SENSING SYSTEM BY NANDHA INFOTECH";
?>