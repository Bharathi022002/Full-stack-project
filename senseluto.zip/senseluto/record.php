<?php
include("conn.php");
$uid=$_SESSION['userid'];
$name=$_SESSION['name'];
$gid=$_SESSION['gid'];


$temp_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";
$data_query="SELECT * FROM `sens_data` where `gadget_id`='$gid' ORDER BY `sens_data`.`timestamp` DESC LIMIT 30";

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
   
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		<!--**********************************
            Chat box start
        ***********************************-->
		
		<!--**********************************
            Chat box End
        ***********************************-->
		
		<!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
       <?php include "sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					
					<!-- temp values -->
					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios-glyphs/32/ffffff/temperature.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0">Temperature</h4>
								</div>
								
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Temp</span></th>
											</tr>
										</thead>

										<?php 
                                        $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['temperature'] ?></span>
												</td>
											</tr>	
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
                    <!-- end -->

                    <!-- moisture value -->
					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios-filled/30/ffffff/moisture.png"/>
									</span>
									<h4>Moisture</h4>
								</div>
								
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Moisture</span></th>
											</tr>
										</thead>

										<?php 
                                        $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['moisture'] ?></span>
												</td>
											</tr>	
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
                    <!-- end -->

                    <!-- ph value -->
					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios/30/ffffff/ph-meter.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0">PH      </h4>
								</div>
								
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">PH</span></th>
											</tr>
										</thead>
										<?php 
                                        $part=mysqli_query($con,$temp_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['ph'] ?></span>
												</td>
											</tr>
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
					<!-- end -->

					<div class="col-xl-4 col-xxl-12 col-lg-12">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex align-items-center mr-3">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-warning">
										<img src="https://img.icons8.com/ios/30/ffffff/ph-meter.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0"><?php echo $_SESSION['name']; ?> - Data Log </h4>
								</div>
								
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Temperature</span></th>
												<th><span class="font-w600 text-black fs-16">Moisture</span></th>
												<th><span class="font-w600 text-black fs-16">ph</span></th>
											</tr>
										</thead>
										<?php 
                                        $part=mysqli_query($con,$data_query)or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['temperature'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['moisture'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['ph'] ?></span>
												</td>
											</tr>
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
</body>
</html>