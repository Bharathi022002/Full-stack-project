<?php

session_start();
$con=mysqli_connect("localhost","root","","senseluto")or die("connection error");


$title="SENSELUTO - SOIL SENSING SYSTEM BY NANDHA INFOTECH";
?>