<?php
include("conn.php");
$uid=$_SESSION['$userid'];
$name=$_SESSION['$name'];
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Gymove - Fitness Bootstrap Admin Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
       <?php include "sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">
					
					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios-glyphs/32/ffffff/temperature.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0">Temperature</h4>
								</div>
								<div class="dropdown">
									<button type="button" class="btn btn-primary light btn-md" data-toggle="dropdown" aria-expanded="false">
										Newest
										<i class="fa fa-chevron-down ml-2" aria-hidden="true"></i>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="#">Edit</a>
										<a class="dropdown-item" href="#">Delete</a>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Temp</span></th>
											</tr>
										</thead>

										<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `sens_data` ")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['temperature'] ?></span>
												</td>
											</tr>	
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios-filled/30/ffffff/moisture.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0">Moisture</h4>
								</div>
								<div class="dropdown">
									<button type="button" class="btn btn-primary light btn-md" data-toggle="dropdown" aria-expanded="false">
										Newest
										<i class="fa fa-chevron-down ml-2" aria-hidden="true"></i>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="#">Edit</a>
										<a class="dropdown-item" href="#">Delete</a>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Moisture</span></th>
											</tr>
										</thead>

										<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `sens_data` ")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['moisture'] ?></span>
												</td>
											</tr>	
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>

					<div class="col-xl-4 col-xxl-4 col-lg-6">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex mr-3 align-items-center">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-danger">
										<img src="https://img.icons8.com/ios/30/ffffff/ph-meter.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0">PH</h4>
								</div>
								<div class="dropdown">
									<button type="button" class="btn btn-primary light btn-md" data-toggle="dropdown" aria-expanded="false">
										Newest
										<i class="fa fa-chevron-down ml-2" aria-hidden="true"></i>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="#">Edit</a>
										<a class="dropdown-item" href="#">Delete</a>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">PH</span></th>
											</tr>
										</thead>
										<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `sens_data` ")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['ph'] ?></span>
												</td>
											</tr>
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
					<div class="col-xl-4 col-xxl-12 col-lg-12">
						<div class="card">
							<div class="card-header bg-white">
								<div class="d-flex align-items-center mr-3">
									<span class="p-sm-3 p-2 mr-sm-3 mr-2 rounded-circle bg-warning">
										<img src="https://img.icons8.com/ios/30/ffffff/ph-meter.png"/>
									</span>
									<h4 class="fs-20 text-black mb-0"><?php echo $_SESSION['$name']; ?>  data</h4>
								</div>
								<div class="dropdown">
									<button type="button" class="btn btn-primary light btn-md" data-toggle="dropdown" aria-expanded="false">
										Newest
										<i class="fa fa-chevron-down ml-2" aria-hidden="true"></i>
									</button>
									<div class="dropdown-menu">
										<a class="dropdown-item" href="#">Edit</a>
										<a class="dropdown-item" href="#">Delete</a>
									</div>
								</div>
							</div>
							<div class="card-body p-0">
								<div class="table-responsive">
									<table class="table shadow-hover">
										<thead>
											<tr>
												<th><span class="font-w600 text-black fs-16">Date/Time</span></th>
												<th><span class="font-w600 text-black fs-16">Temperature</span></th>
												<th><span class="font-w600 text-black fs-16">Moisture</span></th>
												<th><span class="font-w600 text-black fs-16">ph</span></th>
											</tr>
										</thead>
										<?php 
                                        $part=mysqli_query($con,"SELECT * FROM `sens_data` WHERE `userid`='$uid' ")or die(mysqli_error($con));
                                        while($p=mysqli_fetch_array($part))
                                            {
											?>
										<tbody>
											<tr>
												<td>
													<span class="fs-14"><?php echo $p['timestamp'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['temperature'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['moisture'] ?></span>
												</td>
												<td>
													<span class="fs-14"><?php echo $p['ph'] ?></span>
												</td>
											</tr>
										</tbody>
										<?php 
									}
									?>
									</table>
								</div>
							</div>
						</div>
					</div>
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
</body>
</html>