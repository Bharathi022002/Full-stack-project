<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">
                    <li><a  href="dashboard.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Dashboard</span>
						</a>
                        
                    </li>
                    <li><a  href="gadgets-statistic.php" aria-expanded="false">
							<i class="flaticon-381-television"></i>
							<span class="nav-text">Gadget Statistics</span>
						</a>
                       
                    </li>
                    <li><a  href="map.php" aria-expanded="false">
							<i class="fa fa-map-o" aria-hidden="true"></i>
							<span class="nav-text">Distance Maps</span>
						</a>
                       
                    </li>
                    <li><a  href="record.php" aria-expanded="false">
							<i class="fa fa-address-book-o" aria-hidden="true"></i>
							<span class="nav-text">Gadget Records</span>
						</a>
                        
                    </li>

                    <li><a  href="field-data.php" aria-expanded="false">
							<i class="fa fa-envira" aria-hidden="true"></i>
							<span class="nav-text">Field Data</span>
						</a>
                        
                    </li>
                    <li><a  href="datagallery.php" aria-expanded="false">
							<i class="fa fa-picture-o" aria-hidden="true"></i>
							<span class="nav-text">Field Data gallery</span>
						</a>
                        
                    </li>

                    <li><a  href="gadgets-table.php" aria-expanded="false">
                           <i class="fa fa-table" aria-hidden="true"></i>
                            <span class="nav-text">Table</span>
                        </a>
                        
                    </li>
                 
                    <li><a  href="profile.php" aria-expanded="false">
						<i class="fa fa-user" aria-hidden="true"></i>
							<span class="nav-text">Profile</span>
						</a>   
                    </li>

                    <li><a  href="agronamist-dashboard.php" aria-expanded="false">
						<i class="fa fa-handshake-o" aria-hidden="true"></i>
							<span class="nav-text">Agronamist details</span>
						</a>   
                    </li>

                    <li><a  href="faq.php" aria-expanded="false">
						<i class="fa fa-cogs" aria-hidden="true"></i>
							<span class="nav-text">FAQs</span>
						</a>   
                    </li>

                    <li><a  href="recomendation.php" aria-expanded="false">
						<i class="fa fa-thumbs-up" aria-hidden="true"></i>
							<span class="nav-text">Suggestion</span>
						</a>   
                    </li>
                </ul>
				
				
			</div>
        </div>