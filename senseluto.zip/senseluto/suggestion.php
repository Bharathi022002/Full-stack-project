<?php 
include("conn.php");
$uid=$_SESSION['userid'];

if(isset($_POST['create']))
{
    $qn1=$_POST["qn1"];
    $qn2=$_POST["qn2"];
    $qn3=$_POST["qn3"];
    $qn4=$_POST["qn4"];
    $qn5=$_POST["qn5"];
    
    mysqli_query($con,"INSERT INTO `problem`( `userid`, `qn1`, `qn2`, `qn3`, `qn4`, `qn5`) VALUES ('$uid','$qn1','$qn2','$qn3','$qn4','$qn5')")or die(mysqli_error($con));
    
}    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <!-- Datatable -->
    <link href="./vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
        
        


        
        
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
                    <ol class="breadcrumb">
                        
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Problem and solution of coconut</a></li>
                    </ol>
                </div>
                
                <div class="tab-content">
                                            <div id="profile-settings" class="tab-pane fade active show">
                                                <div class="pt-3">
                                                    <div class="settings-form">
                                                        
                                                        <form method="POST" >
                                                            
                                                            <div class="form-group">
                                                                    <label><h4>What was the problem?</h4></label>
                                                                    <input name="qn1" type="text" class="form-control" >
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label><h4>What was the problem?</h4></label>
                                                                    <input name="qn2" type="text" class="form-control" >
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label><h4>What was the problem?</h4></label>
                                                                    <input name="qn3" type="text" class="form-control" >
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label><h4>What was the problem?</h4></label>
                                                                    <input name="qn4" type="text" class="form-control" >
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label><h4>What was the problem?</h4></label>
                                                                    <input name="qn5" type="text" class="form-control" >
                                                                    
                                                            </div>
                                                            
                                                            <button class="btn btn-primary" type="submit" name="create">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                </div>

                                        
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
    <script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>
    
    <!-- Datatable -->
    <script src="./vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="./js/plugins-init/datatables.init.js"></script>

</body>
</html>