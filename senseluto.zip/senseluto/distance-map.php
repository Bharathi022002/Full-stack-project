<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Gymove - Fitness Bootstrap Admin Dashboard</title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link rel="stylesheet" href="./vendor/chartist/css/chartist.min.css">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>
<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->

    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		
		
		<!--**********************************
            Header start
        ***********************************-->
  <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->
		
		<!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <!-- row -->
			<div class="container-fluid">
				<div class="row">	
					<div class="col-xl-12 col-xxl-12">	
						<div class="row">
							<div class="col-xl-12">
								<div class="card">
									<div class="card-header d-md-flex d-block pb-0 border-0">	
										<div class="mr-2 mb-md-0 mb-3">
											<h4 class="text-black fs-20">Maps Route</h4>
										</div>
										<div class="d-flex flex-wrap align-items-center">
											<div class="custom-control check-switch custom-checkbox mr-4 mb-2">
												<input type="checkbox" class="custom-control-input" id="customCheck9">
												<label class="custom-control-label" for="customCheck9">Highlighted</label>
											</div>
											<div class="custom-control custom-switch toggle-switch text-right mr-4 mb-2">
												<input type="checkbox" class="custom-control-input" id="customSwitch11">
												<label class="custom-control-label" for="customSwitch11">Name</label>
											</div>
											<div class="custom-control custom-switch toggle-switch text-right mb-2">
												<input type="checkbox" class="custom-control-input" id="customSwitch12">
												<label class="custom-control-label" for="customSwitch12">Map</label>
											</div>
										</div>
									</div>
									<div class="card-body">
										<div class="mapouter">
											<div class="gmap_canvas">
												<iframe class="border-0" height="450" id="gmap_canvas" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3916.288908755292!2d76.97038431480293!3d11.016936792158646!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3ba99af1e6d172b1%3A0x35b760f1c94f8019!2sNandha%20Infotech!5e0!3m2!1sen!2sin!4v1641201002272!5m2!1sen!2sin"></iframe>
											</div>
										</div>
									</div>
								</div>
							</div>
							
									
								</div>
							</div>
						</div>
					</div>
					
				</div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->

        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

		<!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->


    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
	<script src="./vendor/chart.js/Chart.bundle.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<!-- Apex Chart -->
	<script src="./vendor/apexchart/apexchart.js"></script>
	<!-- Dashboard 1 -->
	<script src="./js/dashboard/distance-map.js"></script>
</body>
</html>