<?php 
include("conn.php");

if(isset($_POST['submit']))
{
    mysqli_query($con,"UPDATE `agronist` SET `added`='added' WHERE `id`='".$_POST['add']."'")or die(mysqli_error($con));
    
}    
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <!-- Datatable -->
    <link href="./vendor/datatables/css/jquery.dataTables.min.css" rel="stylesheet">
    <!-- Custom Stylesheet -->
    <link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
    <div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
        
        


        
        
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end ti-comment-alt
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="javascript:void(0)">Table</a></li>
                        <li class="breadcrumb-item active"><a href="javascript:void(0)">Agronamist Data Log</a></li>
                    </ol>
                </div>
                <!-- row -->


                <div class="row">                    
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Gadget Data Log</h4>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table id="example3" class="display min-w850">
                                        <thead>
                                            <tr>
                                                <th>S.No</th>
                                                <th>Name</th>
                                                <th>Phone</th>
                                                <th>Email</th>
                                                <th>Address</th>
                                                <th>Location</th>
                                                <th>Experience</th>
                                                <th>Specialist</th>
                                                <th>Add to cart</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                             $i=1;
                                             $data_query="SELECT * FROM `agronist`";
                                             $part=mysqli_query($con,$data_query)or die(mysqli_error($con));
                                            while($p=mysqli_fetch_array($part))
                                            {
                                            ?>
                                         <tr>
                                            
                                                <th><?php echo $i++ ?></th>
                                                <th><?php echo $p['name'] ?></th>
                                                <th><?php echo $p['phone'] ?></th>
                                                <th><?php echo $p['email'] ?></th>
                                                <th><?php echo $p['address'] ?></th>
                                                <th><?php echo $p['location'] ?></th>
                                                <th><?php echo $p['experience'] ?></th>
                                                <th><?php echo $p['specialist'] ?></th>
                                                <form method="post">
                                                <input type="hidden" class="btn btn-danger btn-sm" value="<?php echo $p['id']?>" name="add" >
                                                <th><input type="submit" class="btn btn-danger btn-sm" value="Add" name="submit" ></th>
                                                </form>
                                            </tr>   
                                            <?php
                                             }
                                            ?>
                                           
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        
    </div>
    <!--**********************************
        Main wrapper end
    ***********************************-->

    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
    <script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
    <script src="./js/deznav-init.js"></script>
    
    <!-- Datatable -->
    <script src="./vendor/datatables/js/jquery.dataTables.min.js"></script>
    <script src="./js/plugins-init/datatables.init.js"></script>
<!-- 
    scripts end
 -->
</body>
</html>
