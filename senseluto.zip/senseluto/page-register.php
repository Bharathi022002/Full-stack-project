<?php
include('conn.php');


if(isset($_POST['register']))
{
    
    $email=$_POST["email"];
	$phone=$_POST["phone"];
    $password=$_POST["password"];
    $name=$_POST["name"];
	$gid=$_POST["gid"];
    $address=$_POST["address"];
    
    
    
    $query="SELECT * FROM `register` WHERE `email`='$email' or `phone`='$phone'";
    $qry=mysqli_query($con,$query)or die(mysqli_error($con));

  
	if(mysqli_num_rows($qry)<1)
    {
    
		$target_dir = 'image/';

            if($_FILES["image"]["name"] != "")
            {

                $path = $target_dir . basename($_FILES["image"]["name"]);
                $imageFileType = strtolower(pathinfo($path,PATHINFO_EXTENSION));
               // $move_photo = move_uploaded_file($_FILES["image"]["name"] .$path); 
            

      
    
					mysqli_query($con,"INSERT INTO `register`(`email`, `phone`, `password`, `name`, `profile`, `gadgetsid`, `address`, `latitude`, `longitude`) VALUES ('$email','$phone','$password','$name','$path','$gid','$address')")or die(mysqli_error($con));
			
				 ?> 
				  <script >
					alert("registration successful..");
					window.location="page-login.php";
				  </script>
				 <?php
			}
        }
	
    else
    {
         ?> 
      <script >
        alert("user already available");
      </script>
     <?php
    }
 
}

 ?>
 <!DOCTYPE html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<!--**********************************
            Content body start
        ***********************************-->

<body class="h-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
					
					<div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <form method="POST" enctype="multipart/form-data">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="index.html"><img src="images/logo-full.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4 text-white">Sign up your account</h4>
                                    
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Username</strong></label>
                                            <input type="text" name="name" class="form-control" placeholder="Krishna">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Email</strong></label>
                                            <input type="email" name="email" class="form-control" placeholder="hello@example.com">
                                        </div>
										 <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Phone Number</strong></label>
                                            <input type="text" name="phone" class="form-control" placeholder="+91 9876543210">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Password</strong></label>
                                            <input type="password" name="password" class="form-control" value="Password">
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Profile</strong></label>
                                            <input type="file" class="form-control" name="image" >
                                        </div>
										<div class="form-group">
                                            <label class="mb-1 text-white"><strong>Gadget Id</strong></label>
                                            <input type="text" class="form-control" name="gid" placeholder="Check the Label for Gadget Id" >
                                        </div>
                                        <div class="form-group">
                                            <label class="mb-1 text-white"><strong>Address</strong></label>
                                            <input type="text" class="form-control" name="address" placeholder="Enter the address here" >
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" name="register" class="btn bg-white text-primary btn-block">Sign me up</button>
                                        </div>
                                    
                                    <div class="new-account mt-3">
                                        <p class="text-white">Already have an account? <a class="text-white" href="page-login.php">Sign in</a></p>
                                    </div>
                                </div>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--**********************************
            Content body start
        ***********************************-->
        

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<script src="./vendor/global/global.min.js"></script>
<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
<script src="./js/custom.min.js"></script>
<script src="./js/deznav-init.js"></script>

</body>
</html>