<?php
include('conn.php');

$uid=$_SESSION['userid'];

if(isset($_POST['submit']))
{
	
	$accuracy=$_POST["accuracy"];
	$repeatability=$_POST["repeatability"];
	$flow_range=$_POST["flow_range"];	
	$pipe_size=$_POST["pipe_size"];
    $liters=$_POST["liters"];
	
	
 		mysqli_query($con,"INSERT INTO `water-usage`(`userid`, `accuracy`, `repeatability`, `flow_range`, `pipe_size`, `liters`, `date`) VALUES ('$uid','$accuracy','$repeatability','$flow_range','$pipe_size','$liters',now())")or die(mysqli_error($con)); 
	}

 ?>
 <!-- html start -->
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title><?=$title?></title>
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="./images/favicon.png">
	<link href="./vendor/bootstrap-select/dist/css/bootstrap-select.min.css" rel="stylesheet">
	<link href="./vendor/lightgallery/css/lightgallery.min.css" rel="stylesheet">
    <link href="./css/style.css" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&family=Roboto:wght@100;300;400;500;700;900&display=swap" rel="stylesheet">
</head>

<body>

    <!--*******************
        Preloader start
    ********************-->
    <div id="preloader">
        <div class="sk-three-bounce">
            <div class="sk-child sk-bounce1"></div>
            <div class="sk-child sk-bounce2"></div>
            <div class="sk-child sk-bounce3"></div>
        </div>
    </div>
    <!--*******************
        Preloader end
    ********************-->


    <!--**********************************
        Main wrapper start
    ***********************************-->
<div id="main-wrapper">

        <!--**********************************
            Nav header start
        ***********************************-->
        <?php include"nav-bar.php"?>
        <!--**********************************
            Nav header end
        ***********************************-->
		
		


		
		
        <!--**********************************
            Header start
        ***********************************-->
        <?php include"header.php"?>
        <!--**********************************
            Header end 
        ***********************************-->

        <!--**********************************
            Sidebar start
        ***********************************-->
        <?php include"sidebar.php"?>
        <!--**********************************
            Sidebar end
        ***********************************-->

        <!--**********************************
            Content body start
        ***********************************-->
        <div class="content-body">
            <div class="container-fluid">
                <div class="page-titles">
					<ol class="breadcrumb">
						<li class="breadcrumb-item"><a href="javascript:void(0)">App</a></li>
						<li class="breadcrumb-item active"><a href="javascript:void(0)">Profile</a></li>
					</ol>
                </div>
                <!-- row -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="profile card card-body px-3 pt-3 pb-0">
                            <div class="profile-head">
                                
                                <div class="profile-info">
									<div class="profile-photo">
										<img src="<?php echo $_SESSION['image']; ?>" alt="" width="70px" height="70px">
									</div>
									<div class="profile-details">
										<div class="profile-name px-3 pt-2">
											<h4 class="text-primary mb-0"><?php echo $_SESSION['name']; ?></h4>
											
										</div>
										<div class="profile-email px-2 pt-2">
											<h4 class="text-muted mb-0"><?php echo $_SESSION['email']; ?></h4>
											
										</div>
										
									</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-xl-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="profile-tab">
                                    <div class="custom-tab-1">
                                        <ul class="nav nav-tabs">
                                        	<li class="nav-item"><a href="#profile-settings" data-toggle="tab" class="nav-link active show">Water-usage details</a>
                                            </li>
                                            
                                            
                                        </ul>
                                        <div class="tab-content">
                                        	<div id="profile-settings" class="tab-pane fade active show">
                                                <div class="pt-3">
                                                    <div class="settings-form">
                                                        <form method="POST">
                                                            
                                                            <div class="form-group">
                                                                <label>Accuracy</label>
                                                                <input type="number" name="accuracy" placeholder="20" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                <label>Repeatability</label>
                                                                <input type="number" name="repeatability" placeholder="20" class="form-control">
                                                            </div>
                                                            <div class="form-group">
                                                                
                                                                    <label>Flow range</label>
                                                                    <input name="flow_range" type="text" class="form-control" placeholder="7 year">
                                                                    
                                                            </div>
                                                            <div class="form-group">
                                                                    <label>Pipe size</label>
                                                                    <input name="aboutme" type="text" class="form-control" placeholder="about me">
                                                                    
                                                                </div>
                                                            
                                                            <button class="btn btn-primary" type="submit" name="submit">Submit</button>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                        </div>
                                    </div>
									
									
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!--**********************************
            Content body end
        ***********************************-->


        <!--**********************************
            Footer start
        ***********************************-->
        <?php include"footer.php"?>
        <!--**********************************
            Footer end
        ***********************************-->

        <!--**********************************
           Support ticket button start
        ***********************************-->

        <!--**********************************
           Support ticket button end
        ***********************************-->

</div>       
    
    <!--**********************************
        Main wrapper end
    ***********************************-->
	
	<!--removeIf(production)-->
        
    <!--**********************************
        Scripts
    ***********************************-->
    <!-- Required vendors -->
    <script src="./vendor/global/global.min.js"></script>
	<script src="./vendor/bootstrap-select/dist/js/bootstrap-select.min.js"></script>
    <script src="./js/custom.min.js"></script>
	<script src="./js/deznav-init.js"></script>
	<script src="./vendor/lightgallery/js/lightgallery-all.min.js"></script>
	<script>
		$('#lightgallery').lightGallery({
			thumbnail:true,
		});
	</script>
    



	
		
</body>

</html>